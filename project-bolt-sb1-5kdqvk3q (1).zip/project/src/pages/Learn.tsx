import { useEffect, useState } from 'react';
import { BookOpen, Search, Crown, Clock, ArrowRight, Loader2, Filter, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Course, Enrollment, Profile } from '@/types';

interface LearnProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
}

const categories = ['All', 'Technology', 'Career', 'Finance', 'Vocational', 'Business', 'Creative'];
const levels = ['All Levels', 'Beginner', 'Intermediate', 'Advanced'];

export function Learn({ navigate, profile, userId }: LearnProps) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [level, setLevel] = useState('All Levels');
  const [showFilters, setShowFilters] = useState(false);
  const [tab, setTab] = useState<'all' | 'enrolled'>('all');

  useEffect(() => {
    window.scrollTo(0, 0);
    loadData();
  }, [userId]);

  const loadData = async () => {
    const [courseRes, enrRes] = await Promise.all([
      supabase.from('courses').select('*').order('created_at', { ascending: false }),
      userId
        ? supabase.from('enrollments').select('*').eq('user_id', userId)
        : Promise.resolve({ data: [] as Enrollment[] | null, error: null }),
    ]);
    if (courseRes.data) setCourses(courseRes.data as Course[]);
    if (enrRes.data) setEnrollments(enrRes.data as Enrollment[]);
    setLoading(false);
  };

  const enrolledIds = new Set(enrollments.map((e) => e.course_id));

  let filtered = courses.filter((c) => {
    if (search.trim() && !c.title.toLowerCase().includes(search.toLowerCase().trim())) return false;
    if (category !== 'All' && c.category !== category) return false;
    if (level !== 'All Levels' && c.level !== level) return false;
    if (tab === 'enrolled' && !enrolledIds.has(c.id)) return false;
    return true;
  });

  const getProgress = (courseId: string) =>
    enrollments.find((e) => e.course_id === courseId)?.progress || 0;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-md mx-auto px-4 pt-4 pb-3">
          <h1 className="text-2xl font-bold text-slate-900 mb-3">Learn</h1>

          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search courses..."
              className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-100 border border-transparent focus:border-emerald-400 focus:bg-white outline-none text-sm text-slate-800"
              maxLength={100}
            />
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-slate-500 hover:bg-slate-200"
            >
              {showFilters ? <X className="w-4 h-4" /> : <Filter className="w-4 h-4" />}
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2">
            <button
              onClick={() => setTab('all')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                tab === 'all' ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              All Courses
            </button>
            <button
              onClick={() => setTab('enrolled')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                tab === 'enrolled' ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              My Courses ({enrollments.length})
            </button>
          </div>
        </div>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="max-w-md mx-auto px-4 py-3 bg-white border-b border-slate-200">
          <div className="space-y-3">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">Category</p>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium ${
                      category === cat ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">Level</p>
              <div className="flex flex-wrap gap-1.5">
                {levels.map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setLevel(lvl)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium ${
                      level === lvl ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Continue learning section */}
      {tab === 'all' && enrollments.length > 0 && (
        <div className="max-w-md mx-auto px-4 pt-4">
          <h2 className="text-sm font-bold text-slate-700 mb-2">Continue Learning</h2>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
            {enrollments.slice(0, 5).map((enr) => {
              const course = courses.find((c) => c.id === enr.course_id);
              if (!course) return null;
              return (
                <button
                  key={enr.id}
                  onClick={() => navigate(`/courses/${course.id}`)}
                  className="flex-shrink-0 w-56 bg-white rounded-2xl border border-slate-200 p-4 text-left hover:border-emerald-300 hover:shadow-md transition-all"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                      <BookOpen className="w-4 h-4 text-emerald-600" />
                    </div>
                    <span className="text-xs text-slate-400">{course.category}</span>
                  </div>
                  <h3 className="font-semibold text-sm text-slate-800 leading-snug mb-2 line-clamp-2">{course.title}</h3>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full" style={{ width: `${enr.progress}%` }} />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{enr.progress}% complete</p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Course list */}
      <div className="max-w-md mx-auto px-4 pt-4 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-slate-400 text-sm">No courses found</p>
          </div>
        ) : (
          filtered.map((course) => {
            const enrolled = enrolledIds.has(course.id);
            const progress = getProgress(course.id);
            const locked = course.is_premium && !profile?.is_premium;
            return (
              <button
                key={course.id}
                onClick={() => navigate(`/courses/${course.id}`)}
                className="w-full bg-white rounded-2xl border border-slate-200 p-4 text-left hover:border-emerald-300 hover:shadow-md transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 ${categoryColor(course.category)}`}>
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] text-slate-400 font-medium">{course.category}</span>
                      {course.is_premium && (
                        <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[9px] font-bold">
                          <Crown className="w-2.5 h-2.5" /> Pro
                        </span>
                      )}
                    </div>
                    <h3 className="font-semibold text-sm text-slate-800 leading-snug mb-1 line-clamp-2">{course.title}</h3>
                    <p className="text-xs text-slate-500 line-clamp-2 mb-2">{course.description}</p>
                    <div className="flex items-center gap-3 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {course.duration_hours}h</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">{course.level}</span>
                    </div>
                    {enrolled ? (
                      <div className="mt-2">
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full" style={{ width: `${progress}%` }} />
                        </div>
                        <p className="text-[11px] text-emerald-600 font-medium mt-1">{progress}% complete</p>
                      </div>
                    ) : locked ? (
                      <div className="mt-2 flex items-center gap-1 text-xs font-semibold text-amber-600">
                        <Crown className="w-3.5 h-3.5" /> Unlock with Premium
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    ) : (
                      <div className="mt-2 flex items-center gap-1 text-xs font-semibold text-emerald-600">
                        Start Learning Free <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}

function categoryColor(category: string): string {
  const map: Record<string, string> = {
    Technology: 'bg-gradient-to-br from-blue-500 to-indigo-600',
    Career: 'bg-gradient-to-br from-emerald-500 to-teal-600',
    Finance: 'bg-gradient-to-br from-amber-500 to-orange-600',
    Vocational: 'bg-gradient-to-br from-rose-500 to-pink-600',
    Business: 'bg-gradient-to-br from-cyan-500 to-blue-600',
    Creative: 'bg-gradient-to-br from-violet-500 to-purple-600',
  };
  return map[category] || 'bg-gradient-to-br from-slate-500 to-slate-700';
}
