import { useEffect, useState } from 'react';
import { Briefcase, MapPin, Building2, Crown, Lock, Search, Loader2, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Opportunity, Profile } from '@/types';
import { AdBanner } from '@/components/AdBanner';

interface OpportunitiesProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
}

const typeConfig: Record<string, { color: string; label: string }> = {
  job: { color: 'bg-emerald-100 text-emerald-700', label: 'Job' },
  internship: { color: 'bg-blue-100 text-blue-700', label: 'Internship' },
  gig: { color: 'bg-violet-100 text-violet-700', label: 'Gig' },
  scholarship: { color: 'bg-amber-100 text-amber-700', label: 'Scholarship' },
};

export function Opportunities({ navigate, profile, userId }: OpportunitiesProps) {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    let query = supabase.from('opportunities').select('*');
    if (typeFilter !== 'All') query = query.eq('type', typeFilter);
    if (search.trim()) query = query.ilike('title', `%${search.trim()}%`);
    query.order('created_at', { ascending: false }).then(({ data }) => {
      setOpportunities((data as Opportunity[]) || []);
      setLoading(false);
    });
  }, [search, typeFilter]);

  const types = ['All', 'job', 'internship', 'gig', 'scholarship'];

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Opportunities</h1>
          <p className="text-slate-500">Jobs, internships, gigs, and scholarships to jumpstart your career</p>
        </div>

        <div className="mb-6">
          <AdBanner slot="opportunities-banner" userId={userId} />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search opportunities..."
                className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100 outline-none text-sm text-slate-800"
                maxLength={100}
              />
            </div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm text-slate-800 bg-white"
            >
              {types.map((t) => (
                <option key={t} value={t}>
                  {t === 'All' ? 'All Types' : t.charAt(0).toUpperCase() + t.slice(1) + 's'}
                </option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : opportunities.length === 0 ? (
          <div className="text-center py-20">
            <Briefcase className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-400 text-lg">No opportunities found. Check back soon!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {opportunities.map((opp) => {
              const tc = typeConfig[opp.type] || typeConfig.job;
              const locked = opp.is_premium && !profile?.is_premium;
              return (
                <div
                  key={opp.id}
                  className={`bg-white rounded-2xl border p-5 transition-all relative ${
                    locked ? 'border-amber-200' : 'border-slate-200 hover:shadow-lg'
                  }`}
                >
                  {opp.is_premium && (
                    <span className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500 text-white text-xs font-bold shadow-sm">
                      <Crown className="w-3 h-3" />
                      Premium
                    </span>
                  )}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center flex-shrink-0">
                      <Briefcase className="w-5 h-5 text-slate-500" />
                    </div>
                    <div className="min-w-0 pr-20">
                      <h3 className="font-bold text-slate-800 leading-snug">{opp.title}</h3>
                      <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium ${tc.color}`}>
                        {tc.label}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-2">{opp.description}</p>
                  <div className="flex items-center gap-4 text-xs text-slate-400 mb-4">
                    {opp.company && (
                      <span className="flex items-center gap-1"><Building2 className="w-3.5 h-3.5" /> {opp.company}</span>
                    )}
                    {opp.location && (
                      <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {opp.location}</span>
                    )}
                  </div>
                  {locked ? (
                    <button
                      onClick={() => navigate('/premium')}
                      className="w-full py-2.5 rounded-xl font-medium text-sm bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors flex items-center justify-center gap-2"
                    >
                      <Lock className="w-4 h-4" />
                      Unlock with Premium
                    </button>
                  ) : (
                    <button
                      onClick={() => opp.application_url ? window.open(opp.application_url, '_blank') : navigate('/signup')}
                      className="w-full py-2.5 rounded-xl font-medium text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 transition-all flex items-center justify-center gap-2 shadow-sm"
                    >
                      <ExternalLink className="w-4 h-4" />
                      {opp.application_url ? 'Apply Now' : userId ? 'Express Interest' : 'Sign In to Apply'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
