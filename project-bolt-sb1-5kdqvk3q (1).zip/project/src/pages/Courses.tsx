import { useEffect, useState } from 'react';
import { Search, Filter, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Course } from '@/types';
import { CourseCard } from '@/components/CourseCard';
import { AdBanner } from '@/components/AdBanner';

interface CoursesProps {
  navigate: (to: string) => void;
  userId?: string;
}

export function Courses({ navigate, userId }: CoursesProps) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [filter, setFilter] = useState('All');

  const categories = ['All', 'Technology', 'Career', 'Finance', 'Vocational', 'Business', 'Creative'];
  const filters = ['All', 'Free', 'Premium'];

  useEffect(() => {
    window.scrollTo(0, 0);
    let query = supabase.from('courses').select('*');

    if (filter === 'Free') query = query.eq('is_premium', false);
    if (filter === 'Premium') query = query.eq('is_premium', true);
    if (category !== 'All') query = query.eq('category', category);

    if (search.trim()) {
      query = query.ilike('title', `%${search.trim()}%`);
    }

    query.order('created_at', { ascending: false }).then(({ data }) => {
      setCourses((data as Course[]) || []);
      setLoading(false);
    });
  }, [search, category, filter]);

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Explore Courses</h1>
          <p className="text-slate-500">Find the right course to build your skills</p>
        </div>

        <div className="mb-6">
          <AdBanner slot="courses-banner" userId={userId} />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search courses..."
                className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100 outline-none text-sm text-slate-800"
                maxLength={100}
              />
            </div>
            <div className="flex gap-2">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm text-slate-800 bg-white"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm text-slate-800 bg-white"
              >
                {filters.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : courses.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">No courses found. Try adjusting your filters.</p>
          </div>
        ) : (
          <>
            <p className="text-sm text-slate-500 mb-4">{courses.length} course{courses.length !== 1 ? 's' : ''} found</p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <CourseCard
                  key={course.id}
                  course={course}
                  onClick={() => navigate(`/courses/${course.id}`)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
