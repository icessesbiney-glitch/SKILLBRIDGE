import { useEffect } from 'react';
import { Shield, FileText, RotateCcw, ArrowLeft } from 'lucide-react';

interface LegalProps {
  type: 'privacy' | 'terms' | 'refund';
  navigate: (to: string) => void;
}

const config = {
  privacy: {
    icon: Shield,
    title: 'Privacy Policy',
    color: 'from-blue-500 to-indigo-600',
    sections: [
      {
        heading: '1. Information We Collect',
        body: `SkillBridge collects the following information when you create an account: your full name, email address, age, education level, and optional phone number. We also collect data about your learning progress, course enrollments, mentor requests, and platform usage patterns. When you use Google Sign-In, we receive your basic Google profile information (name and email) as authorized by you.`,
      },
      {
        heading: '2. How We Use Your Information',
        body: `Your information is used to: (a) provide and improve our learning services, (b) personalize your course recommendations, (c) connect you with mentors and opportunities, (d) process premium subscriptions and track revenue, (e) send important service notifications, and (f) ensure platform security and prevent fraud. We do not sell your personal data to third parties.`,
      },
      {
        heading: '3. Data Security',
        body: `We implement enterprise-grade security measures including: encrypted data transmission using SSL/TLS, secure password hashing, Row Level Security (RLS) on all database tables, strict access controls, and regular security audits. Your payment information is processed through secure payment gateways and is never stored on our servers. Only you can access your personal learning data.`,
      },
      {
        heading: '4. Data Retention',
        body: `Your account data is retained for as long as your account is active. You may request deletion of your account and associated data at any time by contacting support@skillbridge.org. We retain aggregated, anonymized data for analytics purposes which cannot be traced back to you.`,
      },
      {
        heading: '5. Your Rights',
        body: `You have the right to: (a) access your personal data, (b) correct inaccurate information, (c) request deletion of your data, (d) export your learning data, and (e) opt out of marketing communications. To exercise these rights, contact us at support@skillbridge.org.`,
      },
      {
        heading: '6. Cookies and Tracking',
        body: `SkillBridge uses essential cookies to maintain your login session and remember your preferences. We do not use tracking cookies for advertising purposes. Ad impressions are tracked anonymously to calculate advertising revenue for the platform.`,
      },
      {
        heading: '7. Children Privacy',
        body: `SkillBridge is designed for adults aged 22 and above. We do not knowingly collect information from individuals under 22. If you believe we have collected data from someone under 22, please contact us immediately.`,
      },
      {
        heading: '8. Contact Us',
        body: `If you have questions about this Privacy Policy, contact us at: support@skillbridge.org or +233 30 000 0000. We are located in Accra, Ghana.`,
      },
    ],
  },
  terms: {
    icon: FileText,
    title: 'Terms of Service',
    color: 'from-emerald-500 to-teal-600',
    sections: [
      {
        heading: '1. Acceptance of Terms',
        body: `By creating an account or using SkillBridge, you agree to these Terms of Service. If you do not agree with any part of these terms, you should not use the platform. These terms constitute a legally binding agreement between you and SkillBridge.`,
      },
      {
        heading: '2. Eligibility',
        body: `SkillBridge is available to individuals aged 22 years and older who can read, write, and operate a smartphone or computer. By registering, you confirm that you meet these eligibility requirements and that the information you provide is accurate and truthful.`,
      },
      {
        heading: '3. User Accounts',
        body: `You are responsible for maintaining the confidentiality of your account credentials and for all activities under your account. You agree to: (a) provide accurate registration information, (b) not share your account with others, (c) notify us of any unauthorized access, and (d) not create multiple accounts to abuse free services.`,
      },
      {
        heading: '4. Premium Subscriptions',
        body: `Premium membership grants access to premium courses, exclusive opportunities, and ad-free experience. Subscriptions are valid for the duration specified at purchase (typically 30 days). Premium fees are non-refundable except as stated in our Refund Policy. We reserve the right to modify premium pricing with notice to existing subscribers before renewal.`,
      },
      {
        heading: '5. Acceptable Use',
        body: `You agree not to: (a) use the platform for illegal activities, (b) attempt to hack, disrupt, or compromise platform security, (c) distribute malware or harmful content, (d) harass or discriminate against other users or mentors, (e) copy or redistribute course content without permission, or (f) use automated tools to scrape or abuse platform resources. Violations may result in account termination.`,
      },
      {
        heading: '6. Intellectual Property',
        body: `All course content, platform design, logos, and materials on SkillBridge are owned by SkillBridge or its content partners. You may use content for personal learning only. Unauthorized reproduction, distribution, or commercial use is prohibited.`,
      },
      {
        heading: '7. Mentor Relationships',
        body: `SkillBridge facilitates connections between learners and mentors but is not responsible for the outcome of mentorship relationships. Mentors are independent professionals, not employees of SkillBridge. Any disputes with mentors should be resolved directly between parties.`,
      },
      {
        heading: '8. Revenue and Ownership',
        body: `SkillBridge operates on a sustainable model where ${'10%'} of net revenue is allocated to the platform owner and ${'90%'} is retained for SkillBridge operations, development, and sustainability. This allocation is tracked transparently through the platform's financial system.`,
      },
      {
        heading: '9. Disclaimer',
        body: `SkillBridge provides educational content and opportunity listings on an "as is" basis. We do not guarantee employment outcomes, income results, or the accuracy of third-party opportunity listings. Your success depends on your own effort, skills, and circumstances.`,
      },
      {
        heading: '10. Termination',
        body: `We reserve the right to suspend or terminate accounts that violate these Terms. You may delete your account at any time. Upon termination, your access to premium content ceases immediately.`,
      },
      {
        heading: '11. Changes to Terms',
        body: `We may update these Terms periodically. Users will be notified of significant changes. Continued use after changes constitutes acceptance of the updated Terms.`,
      },
    ],
  },
  refund: {
    icon: RotateCcw,
    title: 'Refund Policy',
    color: 'from-amber-500 to-orange-600',
    sections: [
      {
        heading: '1. Premium Subscription Refunds',
        body: `Premium subscriptions are non-refundable once activated. However, if you experience a technical issue that prevents you from accessing premium content within the first 48 hours of purchase, you may request a full refund by contacting support@skillbridge.org with proof of the issue.`,
      },
      {
        heading: '2. Eligibility for Refund',
        body: `To be eligible for a refund: (a) the request must be made within 48 hours of purchase, (b) you must provide a description of the technical issue preventing access, (c) the premium content must not have been fully consumed, and (d) your account must be in good standing.`,
      },
      {
        heading: '3. Non-Refundable Items',
        body: `The following are non-refundable: (a) premium subscriptions after the 48-hour window, (b) partially consumed premium courses, (c) subscriptions purchased during promotional periods, and (d) accounts terminated due to Terms of Service violations.`,
      },
      {
        heading: '4. Refund Process',
        body: `To request a refund: (1) Email support@skillbridge.org with your account email and transaction details, (2) Include a description of the issue, (3) Allow 5-7 business days for review. Approved refunds will be processed to the original payment method within 10 business days.`,
      },
      {
        heading: '5. Free Content',
        body: `All free courses and features on SkillBridge are provided at no cost and are not subject to refunds. You may discontinue use of free content at any time without obligation.`,
      },
      {
        heading: '6. Subscription Cancellation',
        body: `You can cancel your premium subscription at any time. Cancellation prevents future charges but does not refund the current period. You will retain premium access until the end of your current billing period.`,
      },
      {
        heading: '7. Disputes',
        body: `If you disagree with a refund decision, you may escalate by contacting support@skillbridge.org with additional evidence. We strive to resolve all disputes fairly and promptly.`,
      },
    ],
  },
};

export function Legal({ type, navigate }: LegalProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [type]);

  const content = config[type];
  const Icon = content.icon;
  const lastUpdated = 'August 26, 2026';

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-slate-500 hover:text-emerald-600 mb-6 text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className={`bg-gradient-to-br ${content.color} p-8 text-white`}>
            <div className="flex items-center gap-3 mb-2">
              <Icon className="w-7 h-7" />
              <h1 className="text-2xl font-bold">{content.title}</h1>
            </div>
            <p className="text-white/80 text-sm">Last updated: {lastUpdated}</p>
          </div>

          {/* Content */}
          <div className="p-8">
            <div className="prose prose-slate max-w-none">
              <p className="text-slate-600 leading-relaxed mb-6">
                This {content.title.toLowerCase()} governs your use of SkillBridge, a learning platform
                designed to help adults aged 22 and above build skills, connect with mentors, and find
                opportunities. Please read this document carefully.
              </p>

              {content.sections.map((section) => (
                <div key={section.heading} className="mb-6">
                  <h2 className="text-lg font-bold text-slate-800 mb-2">{section.heading}</h2>
                  <p className="text-slate-600 leading-relaxed text-sm">{section.body}</p>
                </div>
              ))}
            </div>

            {/* Other legal links */}
            <div className="mt-8 pt-6 border-t border-slate-200">
              <p className="text-sm text-slate-500 mb-3">Other legal documents:</p>
              <div className="flex flex-wrap gap-3">
                {type !== 'privacy' && (
                  <button
                    onClick={() => navigate('/legal/privacy')}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-600 text-sm font-medium hover:bg-slate-200 transition-colors"
                  >
                    <Shield className="w-4 h-4" />
                    Privacy Policy
                  </button>
                )}
                {type !== 'terms' && (
                  <button
                    onClick={() => navigate('/legal/terms')}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-600 text-sm font-medium hover:bg-slate-200 transition-colors"
                  >
                    <FileText className="w-4 h-4" />
                    Terms of Service
                  </button>
                )}
                {type !== 'refund' && (
                  <button
                    onClick={() => navigate('/legal/refund')}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 text-slate-600 text-sm font-medium hover:bg-slate-200 transition-colors"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Refund Policy
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
