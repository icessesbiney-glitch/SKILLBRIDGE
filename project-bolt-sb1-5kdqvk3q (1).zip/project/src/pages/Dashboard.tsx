import { useEffect, useState } from 'react';
import { BookOpen, TrendingUp, Crown, Award, Clock, ArrowRight, Briefcase, Handshake } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Profile, Course, Enrollment } from '@/types';
import { CourseCard } from '@/components/CourseCard';
import { AdBanner } from '@/components/AdBanner';

interface DashboardProps {
  navigate: (to: string) => void;
  profile: Profile;
  userId: string;
}

export function Dashboard({ navigate, profile, userId }: DashboardProps) {
  const [enrollments, setEnrollments] = useState<(Enrollment & { course: Course })[]>([]);
  const [recommended, setRecommended] = useState<Course[]>([]);
  const [mentorRequests, setMentorRequests] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
    Promise.all([
      supabase
        .from('enrollments')
        .select('*, course:courses(*)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false }),
      supabase
        .from('courses')
        .select('*')
        .eq('is_premium', false)
        .limit(3),
      supabase
        .from('mentor_requests')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', userId),
    ]).then(([enrRes, recRes, mentorRes]) => {
      if (enrRes.data) setEnrollments(enrRes.data as unknown as (Enrollment & { course: Course })[]);
      if (recRes.data) setRecommended(recRes.data as Course[]);
      setMentorRequests(mentorRes.count || 0);
      setLoading(false);
    });
  }, [userId]);

  const completedCount = enrollments.filter((e) => e.progress === 100).length;
  const inProgressCount = enrollments.filter((e) => e.progress < 100).length;

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-1">
            Welcome back, {profile.full_name || 'Learner'}
          </h1>
          <p className="text-slate-500">Continue your learning journey</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-blue-100 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{enrollments.length}</div>
                <div className="text-xs text-slate-500">Enrolled</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-emerald-100 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{inProgressCount}</div>
                <div className="text-xs text-slate-500">In Progress</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-100 flex items-center justify-center">
                <Award className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{completedCount}</div>
                <div className="text-xs text-slate-500">Completed</div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-violet-100 flex items-center justify-center">
                <Handshake className="w-5 h-5 text-violet-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">{mentorRequests}</div>
                <div className="text-xs text-slate-500">Mentor Requests</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Premium banner */}
            {!profile.is_premium && (
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl p-6 text-white shadow-lg">
                <div className="flex items-center gap-4">
                  <Crown className="w-10 h-10 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">Upgrade to Premium</h3>
                    <p className="text-sm text-white/90">Unlock advanced courses and exclusive opportunities</p>
                  </div>
                  <button
                    onClick={() => navigate('/premium')}
                    className="bg-white text-amber-600 font-semibold px-5 py-2.5 rounded-xl hover:bg-amber-50 transition-colors whitespace-nowrap"
                  >
                    Upgrade
                  </button>
                </div>
              </div>
            )}

            {/* My Courses */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-slate-800">My Courses</h2>
                <button
                  onClick={() => navigate('/courses')}
                  className="text-sm text-emerald-600 font-semibold hover:underline"
                >
                  Browse more
                </button>
              </div>

              {loading ? (
                <div className="text-center py-8 text-slate-400">Loading...</div>
              ) : enrollments.length === 0 ? (
                <div className="text-center py-10">
                  <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 mb-4">You have not enrolled in any courses yet</p>
                  <button
                    onClick={() => navigate('/courses')}
                    className="px-5 py-2.5 rounded-xl text-white bg-emerald-500 hover:bg-emerald-600 font-medium text-sm transition-colors"
                  >
                    Browse Courses
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {enrollments.map((enr) => (
                    <div
                      key={enr.id}
                      className="flex items-center gap-4 p-3 rounded-xl border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all cursor-pointer"
                      onClick={() => navigate(`/courses/${enr.course_id}`)}
                    >
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center flex-shrink-0">
                        <BookOpen className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-slate-800 text-sm truncate">{enr.course.title}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="h-1.5 flex-1 bg-slate-100 rounded-full overflow-hidden max-w-[200px]">
                            <div
                              className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                              style={{ width: `${enr.progress}%` }}
                            />
                          </div>
                          <span className="text-xs text-slate-500">{enr.progress}%</span>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-slate-300 flex-shrink-0" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recommended */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-800 mb-5">Recommended for You</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {recommended.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    onClick={() => navigate(`/courses/${course.id}`)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h3 className="font-bold text-slate-800 mb-4">Your Profile</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-500">Name</span>
                  <span className="font-medium text-slate-700">{profile.full_name || 'Not set'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Age</span>
                  <span className="font-medium text-slate-700">{profile.age || '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Education</span>
                  <span className="font-medium text-slate-700">{profile.education_level}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Plan</span>
                  <span className={`font-medium ${profile.is_premium ? 'text-amber-600' : 'text-slate-700'}`}>
                    {profile.is_premium ? 'Premium' : 'Free'}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick links */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h3 className="font-bold text-slate-800 mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <button
                  onClick={() => navigate('/mentors')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <Handshake className="w-5 h-5 text-emerald-600" />
                  <span className="text-sm font-medium text-slate-700">Find a Mentor</span>
                </button>
                <button
                  onClick={() => navigate('/opportunities')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <Briefcase className="w-5 h-5 text-emerald-600" />
                  <span className="text-sm font-medium text-slate-700">Browse Opportunities</span>
                </button>
                <button
                  onClick={() => navigate('/premium')}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors text-left"
                >
                  <Crown className="w-5 h-5 text-amber-600" />
                  <span className="text-sm font-medium text-slate-700">Go Premium</span>
                </button>
              </div>
            </div>

            {/* Ad */}
            <AdBanner slot="dashboard-sidebar" userId={userId} variant="square" />
          </div>
        </div>
      </div>
    </div>
  );
}
