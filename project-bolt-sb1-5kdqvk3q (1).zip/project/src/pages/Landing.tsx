import { GraduationCap, Users, Briefcase, Award, Zap, Shield, Heart, ArrowRight, CheckCircle, Sparkles, BookOpen, Handshake } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Course } from '@/types';
import { CourseCard } from '@/components/CourseCard';
import { AdBanner } from '@/components/AdBanner';

interface LandingProps {
  navigate: (to: string) => void;
  userId?: string;
}

export function Landing({ navigate, userId }: LandingProps) {
  const [courses, setCourses] = useState<Course[]>([]);

  useEffect(() => {
    supabase
      .from('courses')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(6)
      .then(({ data }) => {
        if (data) setCourses(data as Course[]);
      });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-white to-teal-50" />
        <div className="absolute top-20 right-10 w-72 h-72 bg-emerald-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100 text-emerald-700 text-sm font-medium mb-6">
                <Sparkles className="w-4 h-4" />
                Free learning for everyone aged 22 and above
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight mb-6">
                Bridge the gap from{' '}
                <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  where you are
                </span>{' '}
                to where you want to be
              </h1>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-xl">
                SkillBridge helps unemployed adults build skills, connect with mentors,
                and find real opportunities — whether you are a JHS graduate or looking
                to advance your career. No money required to start.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => navigate('/signup')}
                  className="px-8 py-4 rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 font-semibold text-lg shadow-lg hover:shadow-xl transition-all"
                >
                  Start Learning Free
                </button>
                <button
                  onClick={() => navigate('/courses')}
                  className="px-8 py-4 rounded-xl text-slate-700 bg-white border-2 border-slate-200 hover:border-emerald-300 font-semibold text-lg transition-all"
                >
                  Browse Courses
                </button>
              </div>

              <div className="flex items-center gap-6 mt-10">
                <div>
                  <div className="text-3xl font-bold text-slate-900">10+</div>
                  <div className="text-sm text-slate-500">Courses</div>
                </div>
                <div className="h-10 w-px bg-slate-200" />
                <div>
                  <div className="text-3xl font-bold text-slate-900">6+</div>
                  <div className="text-sm text-slate-500">Mentors</div>
                </div>
                <div className="h-10 w-px bg-slate-200" />
                <div>
                  <div className="text-3xl font-bold text-slate-900">8+</div>
                  <div className="text-sm text-slate-500">Opportunities</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/5212666/pexels-photo-5212666.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Online learning"
                  className="w-full h-[420px] object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-5 max-w-[200px] border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                    <Award className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-800">Certified</div>
                    <div className="text-xs text-slate-500">Learning paths</div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4 border border-slate-100">
                <div className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-rose-500" />
                  <span className="text-sm font-semibold text-slate-700">Free forever</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <AdBanner slot="landing-banner" userId={userId} />
      </div>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
              Everything you need to succeed
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              From learning new skills to landing your first opportunity — SkillBridge is with you every step of the way.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: BookOpen, title: 'Learn Skills', desc: 'Free and premium courses in technology, career, business, and vocational skills.', color: 'from-blue-500 to-indigo-600' },
              { icon: Handshake, title: 'Connect with Mentors', desc: 'Get guidance from experienced professionals who care about your growth.', color: 'from-emerald-500 to-teal-600' },
              { icon: Briefcase, title: 'Find Opportunities', desc: 'Jobs, internships, gigs, and scholarships matched to your skills.', color: 'from-amber-500 to-orange-600' },
              { icon: Zap, title: 'Premium Access', desc: 'Unlock advanced courses and exclusive opportunities with premium membership.', color: 'from-rose-500 to-pink-600' },
              { icon: Shield, title: 'Safe & Secure', desc: 'Your data is protected with enterprise-grade security and encryption.', color: 'from-cyan-500 to-blue-600' },
              { icon: Heart, title: 'Built for Everyone', desc: 'Designed for adults 22+ with no money — from JHS graduates to career changers.', color: 'from-violet-500 to-purple-600' },
            ].map((feature) => (
              <div
                key={feature.title}
                className="group p-6 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:shadow-lg transition-all bg-white"
              >
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
              How SkillBridge works
            </h2>
            <p className="text-lg text-slate-600">Four simple steps to your future</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: '01', icon: GraduationCap, title: 'Sign Up Free', desc: 'Create your account in minutes. No money needed.' },
              { step: '02', icon: BookOpen, title: 'Learn Skills', desc: 'Choose from free courses or unlock premium content.' },
              { step: '03', icon: Handshake, title: 'Get Mentored', desc: 'Connect with experienced mentors for guidance.' },
              { step: '04', icon: Briefcase, title: 'Find Opportunities', desc: 'Apply for jobs, internships, and gigs.' },
            ].map((item) => (
              <div key={item.step} className="relative">
                <div className="text-5xl font-bold text-emerald-100 mb-2">{item.step}</div>
                <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center mb-3">
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-1">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Featured Courses</h2>
              <p className="text-slate-600">Start learning today with our most popular courses</p>
            </div>
            <button
              onClick={() => navigate('/courses')}
              className="hidden sm:flex items-center gap-1 text-emerald-600 font-semibold hover:gap-2 transition-all"
            >
              View all <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <CourseCard key={course.id} course={course} onClick={() => navigate(`/courses/${course.id}`)} />
            ))}
          </div>

          <div className="text-center mt-10 sm:hidden">
            <button
              onClick={() => navigate('/courses')}
              className="px-6 py-3 rounded-xl text-emerald-600 font-semibold border border-emerald-200"
            >
              View all courses
            </button>
          </div>
        </div>
      </section>

      {/* Premium CTA */}
      <section className="py-20 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/20 text-amber-300 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Premium Membership
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Unlock your full potential
          </h2>
          <p className="text-lg text-slate-300 mb-8 max-w-2xl mx-auto">
            Get access to advanced courses, exclusive opportunities, and premium mentorship sessions.
            All for less than the cost of a meal per month.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {['Advanced courses', 'Premium opportunities', 'Priority mentor matching', 'No ads'].map((item) => (
              <div key={item} className="flex items-center gap-2 text-slate-200">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                {item}
              </div>
            ))}
          </div>
          <button
            onClick={() => navigate('/premium')}
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-semibold text-lg shadow-lg transition-all"
          >
            Explore Premium
          </button>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 mb-4">
            <Users className="w-6 h-6 text-emerald-600" />
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Ready to start your journey?
          </h2>
          <p className="text-lg text-slate-600 mb-8">
            Join SkillBridge today. It is free, and it could change your life.
          </p>
          <button
            onClick={() => navigate('/signup')}
            className="px-8 py-4 rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 font-semibold text-lg shadow-lg hover:shadow-xl transition-all"
          >
            Create Free Account
          </button>
        </div>
      </section>
    </div>
  );
}
