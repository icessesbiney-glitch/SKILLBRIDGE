import { useEffect, useState } from 'react';
import { Crown, CheckCircle, Loader2, Zap, Star, Shield, AlertCircle, CreditCard } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Profile } from '@/types';
import { useConfig } from '@/hooks/useConfig';
import { initializePayment, verifyPayment } from '@/lib/paystack';

interface PremiumProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
  onUpgradeComplete: () => void;
}

export function Premium({ navigate, profile, userId, onUpgradeComplete }: PremiumProps) {
  const config = useConfig();
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const price = config['premium_price'] || '15';
  const durationDays = config['premium_duration_days'] || '30';

  const handleUpgrade = async () => {
    if (!userId) {
      navigate('/signin');
      return;
    }

    setError('');
    setProcessing(true);

    try {
      const { data: session } = await supabase.auth.getSession();
      const email = session?.session?.user?.email;
      if (!email) throw new Error('Could not determine your email. Please sign in again.');

      const { authorization_url, reference } = await initializePayment(
        email,
        parseFloat(price),
        userId,
        'premium'
      );

      window.open(authorization_url, '_blank');

      const verified = window.confirm(
        `After completing payment on Paystack, click OK to verify your payment and activate premium.`
      );

      if (verified) {
        try {
          await verifyPayment(reference, userId);
          setSuccess(true);
          setProcessing(false);
          setTimeout(() => {
            onUpgradeComplete();
            navigate('/learn');
          }, 2000);
        } catch (verifyErr) {
          throw new Error(
            verifyErr instanceof Error
              ? `Payment verification: ${verifyErr.message}`
              : 'Payment verification failed. Contact support if you were charged.'
          );
        }
      } else {
        setProcessing(false);
        setError('Payment not confirmed. Complete payment and try again, or contact support if you were charged.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upgrade failed. Please try again.');
      setProcessing(false);
    }
  };

  if (profile?.is_premium) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50 flex items-center justify-center px-4 py-8">
        <div className="max-w-sm w-full bg-white rounded-3xl shadow-xl p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-4">
            <Crown className="w-8 h-8 text-amber-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">You are Premium!</h2>
          <p className="text-slate-600 text-sm">You have access to all premium courses and exclusive opportunities.</p>
          {profile.premium_expires_at && (
            <p className="text-xs text-slate-500 mt-3">
              Active until: {new Date(profile.premium_expires_at).toLocaleDateString()}
            </p>
          )}
          <button
            onClick={() => navigate('/learn')}
            className="mt-6 w-full py-3 rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 font-semibold"
          >
            Go to Learn
          </button>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center px-4 py-8">
        <div className="max-w-sm w-full bg-white rounded-3xl shadow-xl p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Premium Activated!</h2>
          <p className="text-slate-600 text-sm">Welcome to premium. Taking you to your courses...</p>
          <Loader2 className="w-6 h-6 text-emerald-500 animate-spin mx-auto mt-4" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 py-8">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8 pt-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium mb-4">
            <Crown className="w-3.5 h-3.5" />
            Premium Membership
          </div>
          <h1 className="text-3xl font-bold text-white mb-3">Unlock your full potential</h1>
          <p className="text-sm text-slate-300 max-w-xs mx-auto">
            Get unlimited access to premium courses, exclusive opportunities, and priority mentor matching.
          </p>
        </div>

        <div className="space-y-4">
          {/* Free plan */}
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-5">
            <h3 className="text-lg font-bold text-white mb-1">Free</h3>
            <p className="text-slate-400 text-xs mb-4">Perfect for getting started</p>
            <div className="text-3xl font-bold text-white mb-4">
              $0<span className="text-base font-normal text-slate-400">/month</span>
            </div>
            <ul className="space-y-2 mb-5">
              {[
                'Access to free courses',
                'Connect with mentors',
                'Browse public opportunities',
                'Track your progress',
                'Earn task rewards',
              ].map((item) => (
                <li key={item} className="flex items-center gap-2 text-xs text-slate-300">
                  <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
            <button
              onClick={() => navigate('/learn')}
              className="w-full py-2.5 rounded-xl border border-white/20 text-white text-sm font-medium hover:bg-white/10 transition-colors"
            >
              Continue Free
            </button>
          </div>

          {/* Premium plan */}
          <div className="relative bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl p-5 shadow-2xl">
            <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-white text-amber-600 text-[10px] font-bold shadow-md">
              RECOMMENDED
            </div>
            <h3 className="text-lg font-bold text-white mb-1">Premium</h3>
            <p className="text-white/80 text-xs mb-4">Unlock everything</p>
            <div className="text-3xl font-bold text-white mb-1">
              GHS {price}<span className="text-base font-normal text-white/80">/{durationDays} days</span>
            </div>
            <p className="text-white/70 text-[10px] mb-4">Less than GHS 1 per day</p>
            <ul className="space-y-2 mb-5">
              {[
                'All free courses included',
                'Access to premium courses',
                'Exclusive premium opportunities',
                'Priority mentor matching',
                'Ad-free experience',
                'Certificates of completion',
              ].map((item) => (
                <li key={item} className="flex items-center gap-2 text-xs text-white">
                  <CheckCircle className="w-4 h-4 text-white flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
            <button
              onClick={handleUpgrade}
              disabled={processing}
              className="w-full py-3 rounded-xl bg-white text-amber-600 font-bold text-sm hover:bg-amber-50 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {processing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5" />
                  Pay with Paystack
                </>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Trust badges */}
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          {[
            { icon: Shield, text: 'Secure payment' },
            { icon: Star, text: 'Cancel anytime' },
            { icon: CheckCircle, text: 'Instant access' },
          ].map((item) => (
            <div key={item.text} className="flex items-center gap-1.5 text-slate-400 text-xs">
              <item.icon className="w-4 h-4" />
              {item.text}
            </div>
          ))}
        </div>

        <p className="text-center text-[10px] text-slate-500 mt-6 max-w-xs mx-auto">
          Payments processed securely via Paystack. By upgrading, you agree to our{' '}
          <button onClick={() => navigate('/legal/terms')} className="text-slate-400 underline">Terms</button> and{' '}
          <button onClick={() => navigate('/legal/refund')} className="text-slate-400 underline">Refund Policy</button>.
        </p>
      </div>
    </div>
  );
}
