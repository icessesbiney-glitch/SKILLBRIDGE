import { useEffect, useState } from 'react';
import { Star, Send, Loader2, CheckCircle, MessageSquare } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Mentor, Profile, MentorRequest } from '@/types';
import { AdBanner } from '@/components/AdBanner';

interface MentorsProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
}

export function Mentors({ navigate, profile, userId }: MentorsProps) {
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMentor, setSelectedMentor] = useState<Mentor | null>(null);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [myRequests, setMyRequests] = useState<MentorRequest[]>([]);

  useEffect(() => {
    window.scrollTo(0, 0);
    Promise.all([
      supabase.from('mentors').select('*').order('rating', { ascending: false }),
      userId
        ? supabase.from('mentor_requests').select('*').eq('user_id', userId).order('created_at', { ascending: false })
        : Promise.resolve({ data: [] }),
    ]).then(([mentorsRes, reqRes]) => {
      setMentors((mentorsRes.data as Mentor[]) || []);
      if (reqRes.data) setMyRequests(reqRes.data as MentorRequest[]);
      setLoading(false);
    });
  }, [userId]);

  const handleRequest = async () => {
    if (!userId) {
      navigate('/signup');
      return;
    }
    if (!selectedMentor) return;

    setSending(true);
    const { error } = await supabase.from('mentor_requests').insert({
      mentor_id: selectedMentor.id,
      user_id: userId,
      message: message.trim() || `I would like to learn about ${selectedMentor.expertise}.`,
    });

    if (error) {
      setSending(false);
      return;
    }

    setSent(true);
    setSending(false);
    setTimeout(() => {
      setSelectedMentor(null);
      setSent(false);
      setMessage('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Find a Mentor</h1>
          <p className="text-slate-500">Connect with experienced professionals who can guide your journey</p>
        </div>

        <div className="mb-6">
          <AdBanner slot="mentors-banner" userId={userId} />
        </div>

        {/* My requests */}
        {userId && myRequests.length > 0 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-6">
            <h2 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-emerald-600" />
              My Mentor Requests
            </h2>
            <div className="space-y-2">
              {myRequests.slice(0, 3).map((req) => {
                const mentor = mentors.find((m) => m.id === req.mentor_id);
                return (
                  <div key={req.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 text-sm">
                    <span className="text-slate-700">{mentor?.name || 'Unknown mentor'}</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      req.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                      req.status === 'accepted' ? 'bg-emerald-100 text-emerald-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {mentors.map((mentor) => (
              <div key={mentor.id} className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                    {mentor.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-bold text-slate-800 truncate">{mentor.name}</h3>
                    <p className="text-sm text-emerald-600 font-medium">{mentor.expertise}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="text-sm font-semibold text-slate-700">{mentor.rating}</span>
                      <span className="text-xs text-slate-400">· {mentor.years_experience} yrs</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-3">{mentor.bio}</p>
                <button
                  onClick={() => {
                    if (!userId) {
                      navigate('/signup');
                    } else {
                      setSelectedMentor(mentor);
                    }
                  }}
                  disabled={!mentor.is_available}
                  className={`w-full py-2.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-2 ${
                    mentor.is_available
                      ? 'text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-md'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  {mentor.is_available ? 'Request Mentorship' : 'Currently Unavailable'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Request modal */}
      {selectedMentor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setSelectedMentor(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
            {sent ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-emerald-600" />
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-1">Request Sent!</h3>
                <p className="text-sm text-slate-500">Your mentor request has been submitted. You will be contacted soon.</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold">
                    {selectedMentor.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">Request Mentorship</h3>
                    <p className="text-sm text-slate-500">from {selectedMentor.name}</p>
                  </div>
                </div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Your message (optional)</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  placeholder={`Tell ${selectedMentor.name} what you hope to learn...`}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100 outline-none text-sm text-slate-800 resize-none"
                  maxLength={500}
                />
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => setSelectedMentor(null)}
                    className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium text-sm hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleRequest}
                    disabled={sending}
                    className="flex-1 py-2.5 rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    Send Request
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
