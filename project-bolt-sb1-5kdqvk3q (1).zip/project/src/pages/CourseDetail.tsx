import { useEffect, useState } from 'react';
import { ArrowLeft, BookOpen, Clock, Crown, Lock, CheckCircle, PlayCircle, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Course, Lesson, Enrollment, Profile } from '@/types';
import { AdBanner } from '@/components/AdBanner';

interface CourseDetailProps {
  courseId: string;
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
}

export function CourseDetail({ courseId, navigate, profile, userId }: CourseDetailProps) {
  const [course, setCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [enrollment, setEnrollment] = useState<Enrollment | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
    Promise.all([
      supabase.from('courses').select('*').eq('id', courseId).maybeSingle(),
      supabase.from('lessons').select('*').eq('course_id', courseId).order('lesson_order', { ascending: true }),
    ]).then(async ([courseRes, lessonsRes]) => {
      if (courseRes.data) setCourse(courseRes.data as Course);
      if (lessonsRes.data) {
        setLessons(lessonsRes.data as Lesson[]);
        const firstPreview = (lessonsRes.data as Lesson[]).find((l) => l.is_preview);
        if (firstPreview) setActiveLesson(firstPreview);
      }

      if (userId) {
        const { data: enr } = await supabase
          .from('enrollments')
          .select('*')
          .eq('course_id', courseId)
          .eq('user_id', userId)
          .maybeSingle();
        if (enr) setEnrollment(enr as Enrollment);
      }
      setLoading(false);
    });
  }, [courseId, userId]);

  const canAccess = (lesson: Lesson) => {
    if (lesson.is_preview) return true;
    if (!course?.is_premium) return true;
    if (profile?.is_premium) return true;
    return false;
  };

  const handleEnroll = async () => {
    if (!userId) {
      navigate('/signup');
      return;
    }
    if (course?.is_premium && !profile?.is_premium) {
      navigate('/premium');
      return;
    }

    const { data, error: err } = await supabase
      .from('enrollments')
      .insert({ course_id: courseId, user_id: userId })
      .select('*')
      .maybeSingle();

    if (err) {
      setError(err.message);
      return;
    }
    if (data) setEnrollment(data as Enrollment);
  };

  const handleMarkLessonComplete = async (lessonId: string) => {
    if (!enrollment || !userId) return;

    const totalLessons = lessons.length;
    const completedLessons = totalLessons > 0 ? Math.round(((enrollment.progress / 100) * totalLessons) + 1) : 1;
    const newProgress = Math.min(100, Math.round((completedLessons / totalLessons) * 100));

    const { data, error: err } = await supabase
      .from('enrollments')
      .update({
        progress: newProgress,
        completed_at: newProgress === 100 ? new Date().toISOString() : null,
      })
      .eq('id', enrollment.id)
      .select('*')
      .maybeSingle();

    if (err) {
      setError(err.message);
      return;
    }
    if (data) setEnrollment(data as Enrollment);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 pt-20 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-slate-50 pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-500 text-lg mb-4">Course not found</p>
          <button onClick={() => navigate('/courses')} className="text-emerald-600 font-semibold">Back to Courses</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate('/courses')}
          className="flex items-center gap-2 text-slate-500 hover:text-emerald-600 mb-6 text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Courses
        </button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main */}
          <div className="lg:col-span-2">
            {/* Course header */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden mb-6">
              <div className="h-48 bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center relative">
                <BookOpen className="w-16 h-16 text-white/50" />
                {course.is_premium && (
                  <span className="absolute top-4 right-4 flex items-center gap-1 px-3 py-1.5 rounded-full bg-amber-500 text-white text-xs font-bold shadow-md">
                    <Crown className="w-3.5 h-3.5" />
                    Premium
                  </span>
                )}
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-medium">{course.category}</span>
                  <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-medium">{course.level}</span>
                </div>
                <h1 className="text-2xl font-bold text-slate-900 mb-3">{course.title}</h1>
                <p className="text-slate-600 leading-relaxed mb-4">{course.description}</p>
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {course.duration_hours} hours</span>
                  <span>By {course.instructor_name}</span>
                </div>
              </div>
            </div>

            {/* Lesson viewer */}
            {activeLesson && (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <PlayCircle className="w-5 h-5 text-emerald-600" />
                  <h2 className="text-lg font-bold text-slate-800">{activeLesson.title}</h2>
                </div>
                {canAccess(activeLesson) ? (
                  <>
                    <p className="text-slate-600 leading-relaxed mb-4">{activeLesson.content || activeLesson.description || 'No content available.'}</p>
                    {enrollment && (
                      <button
                        onClick={() => handleMarkLessonComplete(activeLesson.id)}
                        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-50 text-emerald-700 font-medium text-sm hover:bg-emerald-100 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Mark as Complete
                      </button>
                    )}
                  </>
                ) : (
                  <div className="flex items-center gap-3 p-4 rounded-xl bg-amber-50 border border-amber-200">
                    <Lock className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <p className="text-sm text-amber-800">
                      This lesson requires premium access.{' '}
                      <button onClick={() => navigate('/premium')} className="font-semibold underline">Upgrade now</button>
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Lesson list */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-lg font-bold text-slate-800 mb-4">Course Content</h2>
              <div className="space-y-2">
                {lessons.length === 0 ? (
                  <p className="text-slate-400 text-sm py-4 text-center">No lessons available yet.</p>
                ) : (
                  lessons.map((lesson, idx) => {
                    const accessible = canAccess(lesson);
                    return (
                      <div
                        key={lesson.id}
                        className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                          activeLesson?.id === lesson.id
                            ? 'border-emerald-300 bg-emerald-50/50'
                            : 'border-slate-100 hover:border-slate-200'
                        }`}
                      >
                        <button
                          onClick={() => accessible && setActiveLesson(lesson)}
                          disabled={!accessible}
                          className="flex items-center gap-3 flex-1 text-left disabled:cursor-not-allowed"
                        >
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                            accessible ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-400'
                          }`}>
                            {accessible ? (idx + 1) : <Lock className="w-3.5 h-3.5" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className={`text-sm font-medium truncate ${accessible ? 'text-slate-800' : 'text-slate-400'}`}>
                              {lesson.title}
                            </h3>
                            <p className="text-xs text-slate-400">{lesson.duration_minutes} min{lesson.is_preview && ' · Free preview'}</p>
                          </div>
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {error && (
              <div className="mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Enrollment card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sticky top-24">
              {enrollment ? (
                <div>
                  <div className="text-center mb-4">
                    <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3">
                      <Award className="w-7 h-7 text-emerald-600" />
                    </div>
                    <h3 className="font-bold text-slate-800">You are enrolled</h3>
                    <p className="text-sm text-slate-500 mt-1">Keep up the great work!</p>
                  </div>
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-slate-500">Progress</span>
                      <span className="font-bold text-emerald-600">{enrollment.progress}%</span>
                    </div>
                    <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all"
                        style={{ width: `${enrollment.progress}%` }}
                      />
                    </div>
                  </div>
                  {enrollment.progress === 100 && (
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-50 text-amber-700 text-sm font-medium">
                      <Award className="w-4 h-4" />
                      Course completed!
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <h3 className="font-bold text-slate-800 mb-2">
                    {course.is_premium ? 'Premium Course' : 'Free Course'}
                  </h3>
                  <p className="text-sm text-slate-500 mb-4">
                    {course.is_premium
                      ? 'Unlock this course with a premium membership to access all lessons.'
                      : 'Enroll now to start learning and track your progress.'}
                  </p>
                  <button
                    onClick={handleEnroll}
                    className={`w-full py-3 rounded-xl font-semibold text-white transition-all ${
                      course.is_premium && !profile?.is_premium
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600'
                        : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700'
                    } shadow-md`}
                  >
                    {course.is_premium && !profile?.is_premium
                      ? 'Upgrade to Access'
                      : userId
                      ? 'Enroll Now'
                      : 'Sign Up to Enroll'}
                  </button>
                </div>
              )}
            </div>

            <AdBanner slot="course-detail-sidebar" userId={userId} variant="square" />
          </div>
        </div>
      </div>
    </div>
  );
}
