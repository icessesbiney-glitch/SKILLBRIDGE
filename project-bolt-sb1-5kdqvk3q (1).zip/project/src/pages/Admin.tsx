import { useEffect, useState } from 'react';
import { Lock, Users, Crown, Eye, Wallet, Loader2, AlertCircle, ArrowLeft, Activity, DollarSign, TrendingUp, Receipt } from 'lucide-react';
import { useConfig } from '@/hooks/useConfig';

interface AdminStats {
  totalUsers: number;
  premiumUsers: number;
  premiumRevenue: number;
  adImpressions: number;
  adRevenue: number;
  totalRevenue: number;
  ownerAllocation: number;
  retainedEarnings: number;
  ownerPct: number;
  retainedPct: number;
  recentTransactions: { type: string; amount: number; description: string; created_at: string }[];
}

interface AdminProps {
  navigate: (to: string) => void;
}

export function Admin({ navigate }: AdminProps) {
  const config = useConfig();
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [fetching, setFetching] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const fetchStats = async (pwd: string) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const res = await fetch(
      `${supabaseUrl}/functions/v1/admin-stats?key=${encodeURIComponent(pwd)}`
    );
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || `Failed (${res.status})`);
    }
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data as AdminStats;
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setError('Please enter the owner password');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const data = await fetchStats(password.trim());
      setStats(data);
      setAuthed(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const refreshStats = async () => {
    setFetching(true);
    try {
      const data = await fetchStats(password.trim());
      setStats(data);
    } catch {
      // silent
    }
    setFetching(false);
  };

  if (!authed) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center px-4 pb-24">
        <div className="max-w-sm w-full bg-slate-800 rounded-3xl shadow-2xl p-6 border border-slate-700">
          <div className="text-center mb-5">
            <div className="w-12 h-12 rounded-2xl bg-slate-700 flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6 text-slate-400" />
            </div>
            <h1 className="text-lg font-bold text-white">Owner Dashboard</h1>
            <p className="text-xs text-slate-400 mt-1">Enter your password to access financial overview</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-3">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-700 border border-slate-600 focus:border-emerald-400 outline-none text-white text-sm"
              placeholder="Enter password"
              maxLength={100}
              autoFocus
            />

            {error && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-xs">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 font-semibold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Lock className="w-5 h-5" />}
              {loading ? 'Authenticating...' : 'Access Dashboard'}
            </button>
          </form>

          <button
            onClick={() => navigate('/')}
            className="w-full mt-3 text-xs text-slate-500 hover:text-slate-300 flex items-center justify-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to site
          </button>
        </div>
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="min-h-screen bg-slate-900 pb-24">
      <div className="max-w-md mx-auto px-4 pt-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-xl font-bold text-white">Owner Dashboard</h1>
            <p className="text-xs text-slate-400 mt-0.5">Revenue & system overview</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={refreshStats}
              disabled={fetching}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700"
            >
              {fetching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Activity className="w-4 h-4" />}
            </button>
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <StatCard icon={Users} label="Total Users" value={stats.totalUsers.toString()} color="from-blue-500 to-indigo-600" />
          <StatCard icon={Crown} label="Premium Users" value={stats.premiumUsers.toString()} color="from-amber-500 to-orange-600" />
          <StatCard icon={Eye} label="Ad Impressions" value={stats.adImpressions.toLocaleString()} color="from-violet-500 to-purple-600" />
          <StatCard icon={Wallet} label="Owner Profit" value={`$${stats.ownerAllocation.toFixed(2)}`} color="from-emerald-500 to-teal-600" />
        </div>

        {/* Revenue breakdown */}
        <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700 mb-4">
          <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            Revenue Breakdown
          </h2>
          <RevenueRow label="Premium Revenue" amount={stats.premiumRevenue} total={stats.totalRevenue} color="bg-amber-500" />
          <div className="h-3" />
          <RevenueRow label="Ad Revenue" amount={stats.adRevenue} total={stats.totalRevenue} color="bg-violet-500" />
          <div className="pt-3 mt-3 border-t border-slate-700 flex items-center justify-between">
            <span className="text-sm text-slate-300 font-medium">Total Revenue</span>
            <span className="text-xl font-bold text-white">${stats.totalRevenue.toFixed(2)}</span>
          </div>
        </div>

        {/* Profit allocation */}
        <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700 mb-4">
          <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            Profit Allocation
          </h2>
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-slate-300">Owner (Cash-out)</span>
                <span className="text-xs font-bold text-emerald-400">{stats.ownerPct}%</span>
              </div>
              <div className="text-xl font-bold text-white">${stats.ownerAllocation.toFixed(2)}</div>
            </div>
            <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-slate-300">Retained (SkillBridge)</span>
                <span className="text-xs font-bold text-blue-400">{stats.retainedPct}%</span>
              </div>
              <div className="text-xl font-bold text-white">${stats.retainedEarnings.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Recent transactions */}
        <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700">
          <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-400" />
            Recent Transactions
          </h2>
          {stats.recentTransactions.length === 0 ? (
            <p className="text-slate-500 text-xs text-center py-4">No transactions yet.</p>
          ) : (
            <div className="space-y-2">
              {stats.recentTransactions.slice(0, 10).map((tx, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-slate-700/50 last:border-0">
                  <div className="min-w-0 flex-1">
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-medium ${
                      tx.type === 'premium_subscription' ? 'bg-amber-500/20 text-amber-300' : 'bg-violet-500/20 text-violet-300'
                    }`}>
                      {tx.type === 'premium_subscription' ? 'Premium' : 'Ad Revenue'}
                    </span>
                    <p className="text-xs text-slate-400 mt-0.5 truncate">{tx.description || '—'}</p>
                  </div>
                  <div className="text-right flex-shrink-0 ml-2">
                    <div className="text-sm font-semibold text-emerald-400">+${Number(tx.amount).toFixed(2)}</div>
                    <div className="text-[10px] text-slate-500">{new Date(tx.created_at).toLocaleDateString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <p className="text-center text-[10px] text-slate-500 mt-4">
          Read-only dashboard. Owner: {config['owner_allocation_percent'] || '10'}% · Retained: {config['retained_percent'] || '90'}%
        </p>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; color: string }) {
  return (
    <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700">
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-2`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className="text-xl font-bold text-white">{value}</div>
      <div className="text-[11px] text-slate-400 mt-0.5">{label}</div>
    </div>
  );
}

function RevenueRow({ label, amount, total, color }: { label: string; amount: number; total: number; color: string }) {
  const pct = total > 0 ? (amount / total) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-slate-300">{label}</span>
        <span className="text-sm font-semibold text-white">${amount.toFixed(2)}</span>
      </div>
      <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
