import { useEffect, useState, useCallback } from 'react';
import { CheckSquare, Gift, Clock, Loader2, CheckCircle, Circle, AlertCircle, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Task, UserTask, Profile } from '@/types';

interface TasksProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
}

const taskTypeConfig: Record<string, { icon: typeof CheckSquare; color: string; label: string }> = {
  lesson_complete: { icon: CheckSquare, color: 'from-blue-500 to-indigo-600', label: 'Lesson' },
  quiz_pass: { icon: Zap, color: 'from-amber-500 to-orange-600', label: 'Quiz' },
  course_complete: { icon: CheckCircle, color: 'from-emerald-500 to-teal-600', label: 'Course' },
  daily_login: { icon: Clock, color: 'from-violet-500 to-purple-600', label: 'Daily' },
  referral: { icon: Gift, color: 'from-rose-500 to-pink-600', label: 'Referral' },
};

export function Tasks({ navigate, profile, userId }: TasksProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [userTasks, setUserTasks] = useState<UserTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState<string | null>(null);
  const [error, setError] = useState('');

  const loadData = useCallback(async () => {
    const [taskRes, utRes] = await Promise.all([
      supabase.from('tasks').select('*').eq('is_active', true).order('created_at', { ascending: true }),
      userId
        ? supabase.from('user_tasks').select('*, task:tasks(*)').eq('user_id', userId)
        : Promise.resolve({ data: [] as UserTask[] | null, error: null }),
    ]);
    if (taskRes.data) setTasks(taskRes.data as Task[]);
    if (utRes.data) setUserTasks(utRes.data as UserTask[]);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    window.scrollTo(0, 0);
    loadData();
  }, [loadData]);

  const getUserTask = (taskId: string) => userTasks.find((ut) => ut.task_id === taskId);

  const handleStartTask = async (taskId: string) => {
    if (!userId) {
      navigate('/signup');
      return;
    }
    const existing = getUserTask(taskId);
    if (existing) return;

    const { error } = await supabase.from('user_tasks').insert({
      user_id: userId,
      task_id: taskId,
      status: 'pending',
      progress: 0,
    });
    if (error) {
      setError(error.message);
      return;
    }
    loadData();
  };

  const handleClaim = async (taskId: string) => {
    if (!userId) return;
    const ut = getUserTask(taskId);
    if (!ut || ut.status !== 'completed') return;

    setClaiming(taskId);
    setError('');

    try {
      const task = tasks.find((t) => t.id === taskId);
      if (!task) throw new Error('Task not found');

      const { error: updateError } = await supabase
        .from('user_tasks')
        .update({ status: 'claimed', claimed_at: new Date().toISOString() })
        .eq('id', ut.id);
      if (updateError) throw new Error(updateError.message);

      const { error: txError } = await supabase.from('wallet_transactions').insert({
        user_id: userId,
        type: 'task_reward',
        amount: task.reward_amount,
        description: `Task reward: ${task.title}`,
        status: 'success',
      });
      if (txError) throw new Error(txError.message);

      const { error: profileError } = await supabase
        .from('profiles')
        .update({ wallet_balance: (profile?.wallet_balance || 0) + task.reward_amount })
        .eq('id', userId);
      if (profileError) throw new Error(profileError.message);

      loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to claim reward');
    } finally {
      setClaiming(null);
    }
  };

  const totalEarned = userTasks
    .filter((ut) => ut.status === 'claimed')
    .reduce((sum, ut) => sum + (ut.task?.reward_amount || 0), 0);

  const completedCount = userTasks.filter((ut) => ut.status === 'completed' || ut.status === 'claimed').length;
  const pendingRewards = userTasks.filter((ut) => ut.status === 'completed').length;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 px-4 pt-6 pb-6 text-white">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-2 mb-1">
            <CheckSquare className="w-6 h-6" />
            <h1 className="text-2xl font-bold">Tasks</h1>
          </div>
          <p className="text-sm text-white/80">Complete tasks and earn rewards</p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2 mt-4">
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <div className="text-xl font-bold">{completedCount}</div>
              <div className="text-[10px] text-white/80">Completed</div>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <div className="text-xl font-bold">{pendingRewards}</div>
              <div className="text-[10px] text-white/80">To Claim</div>
            </div>
            <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
              <div className="text-xl font-bold">GHS {totalEarned.toFixed(2)}</div>
              <div className="text-[10px] text-white/80">Earned</div>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="max-w-md mx-auto px-4 pt-3">
          <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        </div>
      )}

      {/* Not signed in */}
      {!userId && (
        <div className="max-w-md mx-auto px-4 pt-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
            <Gift className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
            <h3 className="font-bold text-slate-800 mb-1">Sign in to start earning</h3>
            <p className="text-sm text-slate-500 mb-4">Create an account to complete tasks and earn rewards</p>
            <button
              onClick={() => navigate('/signup')}
              className="px-6 py-2.5 rounded-xl text-white bg-emerald-500 hover:bg-emerald-600 font-semibold text-sm transition-colors"
            >
              Get Started Free
            </button>
          </div>
        </div>
      )}

      {/* Task list */}
      <div className="max-w-md mx-auto px-4 pt-4 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
          </div>
        ) : (
          tasks.map((task) => {
            const ut = getUserTask(task.id);
            const config = taskTypeConfig[task.task_type] || taskTypeConfig.daily_login;
            const Icon = config.icon;
            const isCompleted = ut?.status === 'completed' || ut?.status === 'claimed';
            const isClaimed = ut?.status === 'claimed';
            const progressPct = ut ? Math.min(100, (ut.progress / task.target_count) * 100) : 0;

            return (
              <div
                key={task.id}
                className={`bg-white rounded-2xl border p-4 transition-all ${
                  isClaimed ? 'border-slate-100 opacity-60' : 'border-slate-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${config.color} flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-medium">{config.label}</span>
                      <span className="flex items-center gap-0.5 text-xs font-bold text-emerald-600">
                        <Gift className="w-3 h-3" />
                        GHS {task.reward_amount.toFixed(2)}
                      </span>
                    </div>
                    <h3 className="font-semibold text-sm text-slate-800 leading-snug mb-1">{task.title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed mb-3">{task.description}</p>

                    {ut && (
                      <div className="mb-3">
                        <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                          <span>Progress</span>
                          <span>{ut.progress}/{task.target_count}</span>
                        </div>
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all" style={{ width: `${progressPct}%` }} />
                        </div>
                      </div>
                    )}

                    {isClaimed ? (
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400">
                        <CheckCircle className="w-4 h-4" /> Reward claimed
                      </div>
                    ) : isCompleted ? (
                      <button
                        onClick={() => handleClaim(task.id)}
                        disabled={claiming === task.id}
                        className="w-full py-2.5 rounded-xl bg-emerald-500 text-white text-sm font-semibold hover:bg-emerald-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {claiming === task.id ? (
                          <><Loader2 className="w-4 h-4 animate-spin" /> Claiming...</>
                        ) : (
                          <><Gift className="w-4 h-4" /> Claim GHS {task.reward_amount.toFixed(2)}</>
                        )}
                      </button>
                    ) : ut ? (
                      <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                        <Circle className="w-4 h-4 text-slate-300" /> In progress
                      </div>
                    ) : (
                      <button
                        onClick={() => handleStartTask(task.id)}
                        className="w-full py-2.5 rounded-xl bg-slate-100 text-slate-700 text-sm font-semibold hover:bg-slate-200 transition-colors"
                      >
                        Start Task
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Go to wallet link */}
      {userId && totalEarned > 0 && (
        <div className="max-w-md mx-auto px-4 pt-4">
          <button
            onClick={() => navigate('/wallet')}
            className="w-full py-3 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-700 hover:border-emerald-300 transition-colors flex items-center justify-center gap-2"
          >
            View Wallet Balance
          </button>
        </div>
      )}
    </div>
  );
}
