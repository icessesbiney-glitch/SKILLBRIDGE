import { useEffect, useState, useCallback } from 'react';
import { Wallet as WalletIcon, ArrowDownToLine, ArrowUpFromLine, Gift, Loader2, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { WalletTransaction, Profile } from '@/types';
import { useConfig } from '@/hooks/useConfig';

interface WalletProps {
  navigate: (to: string) => void;
  profile: Profile | null;
  userId?: string;
  onRefreshProfile?: () => void;
}

const typeConfig: Record<string, { icon: typeof Gift; color: string; label: string }> = {
  task_reward: { icon: Gift, color: 'text-emerald-600', label: 'Task Reward' },
  referral_bonus: { icon: Gift, color: 'text-blue-600', label: 'Referral Bonus' },
  premium_payment: { icon: ArrowUpFromLine, color: 'text-amber-600', label: 'Premium Payment' },
  withdrawal: { icon: ArrowDownToLine, color: 'text-rose-600', label: 'Withdrawal' },
};

export function Wallet({ navigate, profile, userId, onRefreshProfile }: WalletProps) {
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('mtn');
  const [withdrawPhone, setWithdrawPhone] = useState('');
  const [withdrawing, setWithdrawing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const config = useConfig();

  const minWithdrawal = parseFloat(config['min_wallet_withdrawal'] || '20');
  const currency = config['task_reward_currency'] || 'GHS';

  const loadData = useCallback(async () => {
    if (!userId) {
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from('wallet_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (data) setTransactions(data as WalletTransaction[]);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    window.scrollTo(0, 0);
    loadData();
  }, [loadData]);

  const handleWithdraw = async () => {
    if (!userId || !profile) return;
    setError('');
    setSuccess('');

    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Enter a valid amount');
      return;
    }
    if (amount < minWithdrawal) {
      setError(`Minimum withdrawal is ${currency} ${minWithdrawal}`);
      return;
    }
    if (amount > (profile.wallet_balance || 0)) {
      setError('Insufficient balance');
      return;
    }
    if (!withdrawPhone.trim()) {
      setError('Enter your mobile money number');
      return;
    }

    setWithdrawing(true);
    try {
      const { error: txError } = await supabase.from('wallet_transactions').insert({
        user_id: userId,
        type: 'withdrawal',
        amount: -amount,
        description: `Withdrawal to ${withdrawMethod.toUpperCase()} - ${withdrawPhone}`,
        status: 'pending',
      });
      if (txError) throw new Error(txError.message);

      const { error: profileError } = await supabase
        .from('profiles')
        .update({ wallet_balance: (profile.wallet_balance || 0) - amount })
        .eq('id', userId);
      if (profileError) throw new Error(profileError.message);

      setSuccess(`Withdrawal request for ${currency} ${amount.toFixed(2)} submitted! You will receive it within 24 hours.`);
      setWithdrawAmount('');
      setWithdrawPhone('');
      setShowWithdraw(false);
      loadData();
      onRefreshProfile?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Withdrawal failed');
    } finally {
      setWithdrawing(false);
    }
  };

  if (!userId) {
    return (
      <div className="min-h-screen bg-slate-50 pb-24 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center max-w-sm w-full">
          <WalletIcon className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 mb-1">Sign in to view your wallet</h3>
          <p className="text-sm text-slate-500 mb-4">Create an account to earn rewards and track your balance</p>
          <button
            onClick={() => navigate('/signup')}
            className="px-6 py-2.5 rounded-xl text-white bg-emerald-500 hover:bg-emerald-600 font-semibold text-sm transition-colors"
          >
            Get Started Free
          </button>
        </div>
      </div>
    );
  }

  const balance = profile?.wallet_balance || 0;
  const totalEarned = transactions
    .filter((t) => t.amount > 0 && t.status === 'success')
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const totalWithdrawn = transactions
    .filter((t) => t.type === 'withdrawal' && t.status === 'success')
    .reduce((sum, t) => sum + Math.abs(Number(t.amount)), 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Balance card */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 px-4 pt-6 pb-6 text-white">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-2 mb-1">
            <WalletIcon className="w-6 h-6" />
            <h1 className="text-2xl font-bold">Wallet</h1>
          </div>
          <p className="text-sm text-white/80 mb-4">Your earnings and transactions</p>

          <div className="bg-white/15 backdrop-blur-sm rounded-2xl p-5">
            <p className="text-xs text-white/70 mb-1">Available Balance</p>
            <div className="text-4xl font-bold mb-3">{currency} {balance.toFixed(2)}</div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowWithdraw(!showWithdraw)}
                className="flex-1 py-2.5 rounded-xl bg-white text-emerald-600 text-sm font-bold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-1.5"
              >
                <ArrowDownToLine className="w-4 h-4" /> Withdraw
              </button>
              <button
                onClick={() => navigate('/tasks')}
                className="flex-1 py-2.5 rounded-xl bg-white/20 text-white text-sm font-bold hover:bg-white/30 transition-colors flex items-center justify-center gap-1.5"
              >
                <Gift className="w-4 h-4" /> Earn More
              </button>
            </div>
          </div>

          {/* Mini stats */}
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="bg-white/10 rounded-xl p-3">
              <div className="text-sm font-bold">{currency} {totalEarned.toFixed(2)}</div>
              <div className="text-[10px] text-white/70">Total Earned</div>
            </div>
            <div className="bg-white/10 rounded-xl p-3">
              <div className="text-sm font-bold">{currency} {totalWithdrawn.toFixed(2)}</div>
              <div className="text-[10px] text-white/70">Withdrawn</div>
            </div>
          </div>
        </div>
      </div>

      {/* Withdraw form */}
      {showWithdraw && (
        <div className="max-w-md mx-auto px-4 pt-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
            <h3 className="font-bold text-slate-800 text-sm">Withdraw Funds</h3>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Amount ({currency})</label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder={`Min ${currency} ${minWithdrawal}`}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Mobile Money Provider</label>
              <select
                value={withdrawMethod}
                onChange={(e) => setWithdrawMethod(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm bg-white"
              >
                <option value="mtn">MTN Mobile Money</option>
                <option value="telecel">Telecel Cash</option>
                <option value="airteltigo">AirtelTigo Money</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Mobile Money Number</label>
              <input
                type="tel"
                value={withdrawPhone}
                onChange={(e) => setWithdrawPhone(e.target.value)}
                placeholder="e.g. 0241234567"
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-400 outline-none text-sm"
                maxLength={15}
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowWithdraw(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-600 text-sm font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleWithdraw}
                disabled={withdrawing}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white text-sm font-bold hover:bg-emerald-600 disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {withdrawing ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowDownToLine className="w-4 h-4" />}
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      {error && (
        <div className="max-w-md mx-auto px-4 pt-3">
          <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        </div>
      )}
      {success && (
        <div className="max-w-md mx-auto px-4 pt-3">
          <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">
            <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        </div>
      )}

      {/* Transaction history */}
      <div className="max-w-md mx-auto px-4 pt-4">
        <h2 className="text-sm font-bold text-slate-700 mb-2">Transaction History</h2>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
          </div>
        ) : transactions.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
            <WalletIcon className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm text-slate-400">No transactions yet</p>
            <button
              onClick={() => navigate('/tasks')}
              className="mt-3 px-4 py-2 rounded-xl bg-emerald-50 text-emerald-600 text-sm font-semibold"
            >
              Start earning
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map((tx) => {
              const config = typeConfig[tx.type] || typeConfig.task_reward;
              const Icon = config.icon;
              const isPositive = Number(tx.amount) > 0;
              return (
                <div key={tx.id} className="bg-white rounded-xl border border-slate-200 p-3 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    isPositive ? 'bg-emerald-50' : 'bg-amber-50'
                  }`}>
                    <Icon className={`w-5 h-5 ${config.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-800 truncate">{config.label}</p>
                    <p className="text-xs text-slate-400 truncate">{tx.description || '—'}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {tx.status === 'pending' && (
                        <span className="flex items-center gap-0.5 text-[10px] text-amber-600 font-medium">
                          <Clock className="w-2.5 h-2.5" /> Pending
                        </span>
                      )}
                      {tx.status === 'success' && (
                        <span className="flex items-center gap-0.5 text-[10px] text-emerald-600 font-medium">
                          <CheckCircle className="w-2.5 h-2.5" /> Success
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400">
                        {new Date(tx.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className={`text-sm font-bold flex-shrink-0 ${isPositive ? 'text-emerald-600' : 'text-slate-600'}`}>
                    {isPositive ? '+' : ''}{currency} {Math.abs(Number(tx.amount)).toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
