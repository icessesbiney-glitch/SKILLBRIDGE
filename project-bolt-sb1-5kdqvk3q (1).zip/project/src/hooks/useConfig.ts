import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { SystemConfig } from '@/types';

export function useConfig() {
  const [config, setConfig] = useState<Record<string, string>>({});

  useEffect(() => {
    supabase
      .from('system_config')
      .select('*')
      .then(({ data }) => {
        if (data) {
          const map: Record<string, string> = {};
          (data as SystemConfig[]).forEach((c) => {
            map[c.key] = c.value;
          });
          setConfig(map);
        }
      });
  }, []);

  return config;
}
