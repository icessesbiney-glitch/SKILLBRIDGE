import { Home, BookOpen, CheckSquare, Wallet, User } from 'lucide-react';
import type { Profile } from '@/types';

interface BottomNavProps {
  navigate: (to: string) => void;
  currentPath: string;
  profile: Profile | null;
  onSignOut: () => void;
}

const tabs = [
  { label: 'Home', path: '/', icon: Home },
  { label: 'Learn', path: '/learn', icon: BookOpen },
  { label: 'Tasks', path: '/tasks', icon: CheckSquare },
  { label: 'Wallet', path: '/wallet', icon: Wallet },
  { label: 'Profile', path: '/profile', icon: User },
];

export function BottomNav({ navigate, currentPath, profile, onSignOut }: BottomNavProps) {
  const isActive = (tabPath: string) => {
    if (tabPath === '/') return currentPath === '/';
    return currentPath === tabPath || currentPath.startsWith(tabPath + '/');
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around h-16 max-w-md mx-auto">
        {tabs.map((tab) => {
          const active = isActive(tab.path);
          const Icon = tab.icon;
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`flex flex-col items-center justify-center gap-0.5 px-2 py-1 rounded-lg transition-all relative ${
                active ? 'text-emerald-600' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              {active && (
                <span className="absolute -top-px left-1/2 -translate-x-1/2 w-8 h-0.5 bg-emerald-500 rounded-full" />
              )}
              <Icon
                className={`w-5 h-5 transition-transform ${active ? 'scale-110' : ''}`}
                strokeWidth={active ? 2.5 : 2}
              />
              <span className={`text-[10px] font-medium ${active ? 'font-semibold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
