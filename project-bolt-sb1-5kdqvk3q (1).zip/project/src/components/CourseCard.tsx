import { BookOpen, Crown, Clock, ArrowRight } from 'lucide-react';
import type { Course } from '@/types';

interface CourseCardProps {
  course: Course;
  enrolled?: boolean;
  progress?: number;
  onClick: () => void;
}

export function CourseCard({ course, enrolled, progress, onClick }: CourseCardProps) {
  return (
    <button
      onClick={onClick}
      className="group text-left bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl hover:border-emerald-300 transition-all duration-300"
    >
      <div className="relative h-40 bg-gradient-to-br from-slate-100 to-slate-200 overflow-hidden">
        {course.thumbnail_url ? (
          <img
            src={course.thumbnail_url}
            alt={course.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className={`w-full h-full flex items-center justify-center ${categoryGradient(course.category)}`}>
            <BookOpen className="w-12 h-12 text-white/70" />
          </div>
        )}
        {course.is_premium && (
          <span className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500 text-white text-xs font-bold shadow-md">
            <Crown className="w-3 h-3" />
            Premium
          </span>
        )}
        <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-sm text-slate-700 text-xs font-medium">
          {course.category}
        </span>
      </div>

      <div className="p-5">
        <h3 className="font-bold text-slate-800 text-lg leading-snug group-hover:text-emerald-600 transition-colors mb-2">
          {course.title}
        </h3>
        <p className="text-sm text-slate-500 line-clamp-2 mb-3">
          {course.description}
        </p>

        <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {course.duration_hours}h
          </span>
          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
            {course.level}
          </span>
        </div>

        {enrolled ? (
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-500">Progress</span>
              <span className="font-semibold text-emerald-600">{progress || 0}%</span>
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all"
                style={{ width: `${progress || 0}%` }}
              />
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-sm font-semibold text-emerald-600 group-hover:gap-2 transition-all">
            {course.is_premium ? 'Unlock with Premium' : 'Start Learning Free'}
            <ArrowRight className="w-4 h-4" />
          </div>
        )}
      </div>
    </button>
  );
}

function categoryGradient(category: string): string {
  const map: Record<string, string> = {
    Technology: 'bg-gradient-to-br from-blue-500 to-indigo-600',
    Career: 'bg-gradient-to-br from-emerald-500 to-teal-600',
    Finance: 'bg-gradient-to-br from-amber-500 to-orange-600',
    Vocational: 'bg-gradient-to-br from-rose-500 to-pink-600',
    Business: 'bg-gradient-to-br from-violet-500 to-purple-600',
    Creative: 'bg-gradient-to-br from-cyan-500 to-blue-600',
  };
  return map[category] || 'bg-gradient-to-br from-slate-500 to-slate-700';
}
