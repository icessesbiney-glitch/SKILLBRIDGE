import { GraduationCap, Mail, Phone, MapPin, Shield, FileText, RotateCcw } from 'lucide-react';

interface FooterProps {
  navigate: (to: string) => void;
}

export function Footer({ navigate }: FooterProps) {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">
                Skill<span className="text-emerald-400">Bridge</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Bridging the gap between ambition and opportunity. Free and premium learning for everyone aged 22 and above.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Platform</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/courses')} className="hover:text-emerald-400 transition-colors">Courses</button></li>
              <li><button onClick={() => navigate('/mentors')} className="hover:text-emerald-400 transition-colors">Find Mentors</button></li>
              <li><button onClick={() => navigate('/opportunities')} className="hover:text-emerald-400 transition-colors">Opportunities</button></li>
              <li><button onClick={() => navigate('/premium')} className="hover:text-emerald-400 transition-colors">Premium Access</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/legal/privacy')} className="flex items-center gap-2 hover:text-emerald-400 transition-colors"><Shield className="w-4 h-4" /> Privacy Policy</button></li>
              <li><button onClick={() => navigate('/legal/terms')} className="flex items-center gap-2 hover:text-emerald-400 transition-colors"><FileText className="w-4 h-4" /> Terms of Service</button></li>
              <li><button onClick={() => navigate('/legal/refund')} className="flex items-center gap-2 hover:text-emerald-400 transition-colors"><RotateCcw className="w-4 h-4" /> Refund Policy</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Contact</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2"><Mail className="w-4 h-4 text-emerald-400" /> support@skillbridge.org</li>
              <li className="flex items-center gap-2"><Phone className="w-4 h-4 text-emerald-400" /> +233 30 000 0000</li>
              <li className="flex items-center gap-2"><MapPin className="w-4 h-4 text-emerald-400" /> Accra, Ghana</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-400">
            &copy; {new Date().getFullYear()} SkillBridge. All rights reserved.
          </p>
          <p className="text-xs text-slate-500">
            Empowering learners. Building futures. Sustainable for generations.
          </p>
        </div>
      </div>
    </footer>
  );
}
