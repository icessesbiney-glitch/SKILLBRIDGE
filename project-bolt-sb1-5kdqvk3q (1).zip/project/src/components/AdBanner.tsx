import { useEffect, useRef } from 'react';
import { trackAdImpression } from '@/lib/ads';
import { Megaphone } from 'lucide-react';

interface AdBannerProps {
  slot: string;
  userId?: string;
  variant?: 'horizontal' | 'square';
}

export function AdBanner({ slot, userId, variant = 'horizontal' }: AdBannerProps) {
  const tracked = useRef(false);

  useEffect(() => {
    if (tracked.current) return;
    tracked.current = true;
    trackAdImpression(slot, userId);
  }, [slot, userId]);

  const ads = [
    { title: 'Grow Your Business Online', subtitle: 'Free digital marketing toolkit', color: 'from-blue-500 to-cyan-500' },
    { title: 'Learn to Code in 30 Days', subtitle: 'Bootcamp scholarships available', color: 'from-orange-500 to-amber-500' },
    { title: 'Start Your Freelance Journey', subtitle: 'Join 10,000+ freelancers', color: 'from-emerald-500 to-teal-500' },
    { title: 'Get Certified This Year', subtitle: 'Industry-recognized certificates', color: 'from-rose-500 to-pink-500' },
  ];

  const ad = ads[Math.abs(hashCode(slot)) % ads.length];

  if (variant === 'square') {
    return (
      <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${ad.color} p-6 text-white shadow-lg`}>
        <div className="absolute top-2 right-2 text-[10px] uppercase tracking-wider bg-black/20 px-2 py-0.5 rounded">Ad</div>
        <Megaphone className="w-8 h-8 mb-3 opacity-80" />
        <h4 className="font-bold text-lg leading-tight mb-1">{ad.title}</h4>
        <p className="text-sm text-white/90">{ad.subtitle}</p>
        <button className="mt-4 w-full bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-lg py-2 text-sm font-medium transition-colors">
          Learn More
        </button>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden rounded-xl bg-gradient-to-r ${ad.color} px-6 py-4 text-white shadow-md`}>
      <div className="absolute top-2 right-2 text-[10px] uppercase tracking-wider bg-black/20 px-2 py-0.5 rounded">Sponsored</div>
      <div className="flex items-center gap-4">
        <Megaphone className="w-8 h-8 flex-shrink-0 opacity-80" />
        <div>
          <h4 className="font-semibold text-base leading-tight">{ad.title}</h4>
          <p className="text-sm text-white/90">{ad.subtitle}</p>
        </div>
        <button className="ml-auto flex-shrink-0 bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-lg px-4 py-2 text-sm font-medium transition-colors">
          Learn More
        </button>
      </div>
    </div>
  );
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}
