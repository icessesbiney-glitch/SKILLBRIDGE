import { supabase } from '@/lib/supabase';

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/paystack`;

export interface PaystackInitResponse {
  authorization_url: string;
  reference: string;
}

export interface PaystackVerifyResponse {
  success: boolean;
  amount: number;
  reference: string;
}

export async function initializePayment(
  email: string,
  amount: number,
  userId: string,
  plan: string = 'premium'
): Promise<PaystackInitResponse> {
  const { data: session } = await supabase.auth.getSession();
  const token = session?.session?.access_token;

  const res = await fetch(`${FUNCTION_URL}?action=initialize`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      ...(token ? { apikey: token } : {}),
    },
    body: JSON.stringify({ email, amount, userId, plan }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Payment initialization failed (${res.status})`);
  }

  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data as PaystackInitResponse;
}

export async function verifyPayment(
  reference: string,
  userId: string
): Promise<PaystackVerifyResponse> {
  const res = await fetch(`${FUNCTION_URL}?action=verify`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({ reference, userId }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Payment verification failed (${res.status})`);
  }

  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data as PaystackVerifyResponse;
}

export async function openPaystackPopup(
  email: string,
  amount: number,
  userId: string,
  plan?: string
): Promise<string> {
  const { authorization_url } = await initializePayment(email, amount, userId, plan);
  window.open(authorization_url, '_blank');
  return authorization_url;
}
