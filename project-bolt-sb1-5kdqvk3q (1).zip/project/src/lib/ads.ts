import { useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';

export function trackAdImpression(slot: string, userId?: string) {
  supabase
    .from('ad_impressions')
    .insert({ ad_slot: slot, user_id: userId || null })
    .then(({ error }) => {
      if (error) console.error('Ad tracking error:', error.message);
    });
}

export function useAdImpression(slot: string, userId?: string) {
  const tracked = useRef(false);
  useEffect(() => {
    if (tracked.current) return;
    tracked.current = true;
    trackAdImpression(slot, userId);
  }, [slot, userId]);
}
