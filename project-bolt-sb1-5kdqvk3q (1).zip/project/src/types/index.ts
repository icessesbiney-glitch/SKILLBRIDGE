export interface Profile {
  id: string;
  full_name: string;
  age: number | null;
  education_level: string;
  phone: string;
  is_premium: boolean;
  premium_expires_at: string | null;
  is_admin: boolean;
  wallet_balance: number;
  paystack_customer_code: string | null;
  created_at: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  level: string;
  thumbnail_url: string | null;
  is_premium: boolean;
  instructor_name: string;
  duration_hours: number;
  created_at: string;
}

export interface Lesson {
  id: string;
  course_id: string;
  title: string;
  description: string | null;
  content: string | null;
  video_url: string | null;
  duration_minutes: number;
  lesson_order: number;
  is_preview: boolean;
}

export interface Enrollment {
  id: string;
  user_id: string;
  course_id: string;
  progress: number;
  completed_at: string | null;
  created_at: string;
}

export interface Mentor {
  id: string;
  name: string;
  expertise: string;
  bio: string | null;
  avatar_url: string | null;
  rating: number;
  years_experience: number;
  is_available: boolean;
}

export interface MentorRequest {
  id: string;
  user_id: string;
  mentor_id: string;
  message: string;
  status: string;
  created_at: string;
}

export interface Opportunity {
  id: string;
  title: string;
  description: string;
  type: string;
  location: string;
  company: string;
  application_url: string | null;
  is_premium: boolean;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  task_type: string;
  reward_amount: number;
  target_count: number;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
}

export interface UserTask {
  id: string;
  user_id: string;
  task_id: string;
  status: string;
  progress: number;
  completed_at: string | null;
  claimed_at: string | null;
  created_at: string;
  task?: Task;
}

export interface WalletTransaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  description: string;
  reference: string | null;
  status: string;
  created_at: string;
}

export interface SystemConfig {
  key: string;
  value: string;
}
