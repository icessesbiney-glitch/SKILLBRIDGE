import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from '@/hooks/useRouter';
import { BottomNav } from '@/components/BottomNav';
import { Landing } from '@/pages/Landing';
import { SignUp } from '@/pages/SignUp';
import { SignIn } from '@/pages/SignIn';
import { Learn } from '@/pages/Learn';
import { Tasks } from '@/pages/Tasks';
import { Wallet } from '@/pages/Wallet';
import { Courses } from '@/pages/Courses';
import { CourseDetail } from '@/pages/CourseDetail';
import { Mentors } from '@/pages/Mentors';
import { Opportunities } from '@/pages/Opportunities';
import { Premium } from '@/pages/Premium';
import { Admin } from '@/pages/Admin';
import { Legal } from '@/pages/Legal';
import { Loader2 } from 'lucide-react';

// Routes that show the bottom tab bar (main app sections)
const tabRoutes = ['/', '/learn', '/tasks', '/wallet', '/profile', '/courses', '/mentors', '/opportunities'];

function App() {
  const { session, user, profile, loading, signOut, refreshProfile } = useAuth();
  const { route, navigate } = useRouter();
  const { path } = route;

  useEffect(() => {
    if (session && (path === '/signin' || path === '/signup')) {
      navigate('/learn');
    }
  }, [session, path, navigate]);

  // Protected routes
  const protectedRoutes = ['/tasks', '/wallet', '/profile'];
  if (protectedRoutes.includes(path) && !loading && !session) {
    navigate('/signin');
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  const userId = user?.id;
  const showBottomNav = tabRoutes.some((r) => path === r || (r !== '/' && path.startsWith(r)));

  // Admin route: standalone, no bottom nav
  if (path === '/admin' || path.startsWith('/admin')) {
    return <Admin navigate={navigate} />;
  }

  // Legal routes: standalone
  if (path.startsWith('/legal/')) {
    const legalType = path.split('/')[2];
    if (legalType === 'privacy' || legalType === 'terms' || legalType === 'refund') {
      return <Legal type={legalType} navigate={navigate} />;
    }
  }

  // Auth routes: standalone
  if (path === '/signup') return <SignUp navigate={navigate} />;
  if (path === '/signin') return <SignIn navigate={navigate} />;

  // Premium: standalone with nav
  if (path === '/premium') {
    return (
      <Premium navigate={navigate} profile={profile} userId={userId} onUpgradeComplete={refreshProfile} />
    );
  }

  // Course detail: standalone
  if (path.startsWith('/courses/')) {
    return (
      <CourseDetail
        courseId={path.split('/')[2]}
        navigate={navigate}
        profile={profile}
        userId={userId}
      />
    );
  }

  return (
    <>
      <div className="min-h-screen bg-slate-50">
        {path === '/' && <Landing navigate={navigate} userId={userId} />}
        {path === '/learn' && <Learn navigate={navigate} profile={profile} userId={userId} />}
        {path === '/tasks' && <Tasks navigate={navigate} profile={profile} userId={userId} />}
        {path === '/wallet' && (
          <Wallet
            navigate={navigate}
            profile={profile}
            userId={userId}
            onRefreshProfile={refreshProfile}
          />
        )}
        {path === '/courses' && <Courses navigate={navigate} userId={userId} />}
        {path === '/mentors' && <Mentors navigate={navigate} profile={profile} userId={userId} />}
        {path === '/opportunities' && (
          <Opportunities navigate={navigate} profile={profile} userId={userId} />
        )}

        {/* Profile route */}
        {path === '/profile' && (
          <ProfilePage navigate={navigate} profile={profile} userId={userId} onSignOut={() => signOut()} />
        )}

        {/* Fallback */}
        {!tabRoutes.includes(path) && !path.startsWith('/courses/') && path !== '/courses' && (
          <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 pb-24">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-slate-300 mb-3">404</h1>
              <p className="text-slate-500 mb-4 text-sm">Page not found</p>
              <button onClick={() => navigate('/')} className="text-emerald-600 font-semibold text-sm">
                Go home
              </button>
            </div>
          </div>
        )}
      </div>

      {showBottomNav && (
        <BottomNav navigate={navigate} currentPath={path} profile={profile} onSignOut={() => signOut()} />
      )}
    </>
  );
}

// Inline profile page for mobile
function ProfilePage({
  navigate,
  profile,
  userId,
  onSignOut,
}: {
  navigate: (to: string) => void;
  profile: import('@/types').Profile | null;
  userId?: string;
  onSignOut: () => void;
}) {
  if (!profile) {
    navigate('/signin');
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 px-4 pt-6 pb-6 text-white">
        <div className="max-w-md mx-auto">
          <h1 className="text-2xl font-bold mb-4">Profile</h1>
          <div className="flex items-center gap-3">
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold">
              {profile.full_name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div>
              <h2 className="text-lg font-bold">{profile.full_name || 'User'}</h2>
              <p className="text-sm text-white/80">{profile.education_level}</p>
              {profile.is_premium && (
                <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full bg-amber-400 text-amber-900 text-[10px] font-bold">
                  Premium Member
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="max-w-md mx-auto px-4 pt-4 space-y-3">
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <h3 className="text-sm font-bold text-slate-800 mb-3">Account Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Age</span>
              <span className="font-medium text-slate-700">{profile.age || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Education</span>
              <span className="font-medium text-slate-700">{profile.education_level}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Phone</span>
              <span className="font-medium text-slate-700">{profile.phone || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Wallet Balance</span>
              <span className="font-medium text-emerald-600">GHS {(profile.wallet_balance || 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Plan</span>
              <span className={`font-medium ${profile.is_premium ? 'text-amber-600' : 'text-slate-700'}`}>
                {profile.is_premium ? 'Premium' : 'Free'}
              </span>
            </div>
          </div>
        </div>

        {/* Quick links */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-1">
          <button
            onClick={() => navigate('/premium')}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors"
          >
            <span className="text-sm font-medium text-slate-700">Premium Membership</span>
            <span className={`text-xs font-bold ${profile.is_premium ? 'text-amber-600' : 'text-slate-400'}`}>
              {profile.is_premium ? 'Active' : 'Upgrade'}
            </span>
          </button>
          <button
            onClick={() => navigate('/mentors')}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors"
          >
            <span className="text-sm font-medium text-slate-700">Find Mentors</span>
          </button>
          <button
            onClick={() => navigate('/opportunities')}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors"
          >
            <span className="text-sm font-medium text-slate-700">Browse Opportunities</span>
          </button>
          <button
            onClick={() => navigate('/admin')}
            className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors"
          >
            <span className="text-sm font-medium text-slate-700">Owner Dashboard</span>
          </button>
        </div>

        {/* Legal links */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-1">
          <button onClick={() => navigate('/legal/privacy')} className="w-full text-left p-3 rounded-xl hover:bg-slate-50 text-sm font-medium text-slate-700">
            Privacy Policy
          </button>
          <button onClick={() => navigate('/legal/terms')} className="w-full text-left p-3 rounded-xl hover:bg-slate-50 text-sm font-medium text-slate-700">
            Terms of Service
          </button>
          <button onClick={() => navigate('/legal/refund')} className="w-full text-left p-3 rounded-xl hover:bg-slate-50 text-sm font-medium text-slate-700">
            Refund Policy
          </button>
        </div>

        {/* Sign out */}
        <button
          onClick={onSignOut}
          className="w-full py-3 rounded-2xl bg-red-50 text-red-600 font-semibold text-sm border border-red-200 hover:bg-red-100 transition-colors"
        >
          Sign Out
        </button>

        <p className="text-center text-[10px] text-slate-400 pt-2">
          SkillBridge · Member since {new Date(profile.created_at).toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}

export default App;
