import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const ownerKey = url.searchParams.get("key") || "";

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Get owner password from system_config
    const { data: cfg } = await supabase
      .from("system_config")
      .select("value")
      .eq("key", "owner_password")
      .maybeSingle();

    const ownerPassword = cfg?.value || "skillbridge_owner_2024";

    if (ownerKey !== ownerPassword) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Total registered users (from auth.users via profiles count)
    const { count: totalUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true });

    // Total premium users
    const { count: premiumUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("is_premium", true);

    // Total premium revenue
    const { data: premiumRev } = await supabase
      .from("revenue_transactions")
      .select("amount")
      .eq("type", "premium_subscription");

    const premiumRevenue = (premiumRev || []).reduce(
      (sum: number, r: { amount: number }) => sum + Number(r.amount),
      0
    );

    // Total ad impressions
    const { count: adCount } = await supabase
      .from("ad_impressions")
      .select("*", { count: "exact", head: true });

    // Ad revenue rate
    const { data: adRateCfg } = await supabase
      .from("system_config")
      .select("value")
      .eq("key", "ad_revenue_per_impression")
      .maybeSingle();

    const adRate = Number(adRateCfg?.value || "0.02");
    const adRevenue = (adCount || 0) * adRate;

    // Owner allocation percent
    const { data: ownerPctCfg } = await supabase
      .from("system_config")
      .select("value")
      .eq("key", "owner_allocation_percent")
      .maybeSingle();

    const ownerPct = Number(ownerPctCfg?.value || "10");
    const retainedPct = 100 - ownerPct;

    const totalRevenue = premiumRevenue + adRevenue;
    const ownerAllocation = (totalRevenue * ownerPct) / 100;
    const retainedEarnings = (totalRevenue * retainedPct) / 100;

    // Recent transactions
    const { data: recentTxns } = await supabase
      .from("revenue_transactions")
      .select("type, amount, description, created_at")
      .order("created_at", { ascending: false })
      .limit(20);

    return new Response(
      JSON.stringify({
        totalUsers: totalUsers || 0,
        premiumUsers: premiumUsers || 0,
        premiumRevenue,
        adImpressions: adCount || 0,
        adRevenue,
        totalRevenue,
        ownerAllocation,
        retainedEarnings,
        ownerPct,
        retainedPct,
        recentTransactions: recentTxns || [],
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
