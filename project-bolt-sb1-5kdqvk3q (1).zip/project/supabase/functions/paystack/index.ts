import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: secretCfg } = await supabase
      .from("system_config")
      .select("value")
      .eq("key", "paystack_secret_key")
      .maybeSingle();
    const paystackSecret = secretCfg?.value || Deno.env.get("PAYSTACK_SECRET_KEY") || "";

    if (!paystackSecret) {
      return new Response(
        JSON.stringify({ error: "Paystack is not configured. Add your secret key in system config." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "";
    const body = await req.json().catch(() => ({}));

    // ---- INITIALIZE TRANSACTION ----
    if (action === "initialize") {
      const { email, amount, userId, plan } = body as {
        email?: string;
        amount?: number;
        userId?: string;
        plan?: string;
      };

      if (!email || !amount || !userId) {
        return new Response(
          JSON.stringify({ error: "Missing email, amount, or userId" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const reference = `SB-${userId.slice(0, 8)}-${Date.now()}`;

      const res = await fetch("https://api.paystack.co/transaction/initialize", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${paystackSecret}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          amount: Math.round(amount * 100),
          reference,
          callback_url: `${url.origin}/#/premium?status=callback`,
          metadata: {
            custom_fields: [
              { display_name: "User ID", variable_name: "user_id", value: userId },
              { display_name: "Plan", variable_name: "plan", value: plan || "premium" },
            ],
          },
        }),
      });

      const data = await res.json();

      if (!data.status) {
        return new Response(
          JSON.stringify({ error: data.message || "Paystack initialization failed" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      await supabase.from("wallet_transactions").insert({
        user_id: userId,
        type: "premium_payment",
        amount: -amount,
        description: `Premium subscription via Paystack`,
        reference,
        status: "pending",
      });

      return new Response(
        JSON.stringify({ authorization_url: data.data.authorization_url, reference }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ---- VERIFY TRANSACTION ----
    if (action === "verify") {
      const { reference, userId } = body as { reference?: string; userId?: string };

      if (!reference) {
        return new Response(
          JSON.stringify({ error: "Missing transaction reference" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const res = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${paystackSecret}` },
      });

      const data = await res.json();

      if (!data.status || data.data.status !== "success") {
        return new Response(
          JSON.stringify({ error: "Payment not verified", status: data.data?.status || "failed" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const paidAmount = data.data.amount / 100;

      // Update transaction status
      await supabase
        .from("wallet_transactions")
        .update({ status: "success" })
        .eq("reference", reference);

      // Activate premium
      const { data: durationCfg } = await supabase
        .from("system_config")
        .select("value")
        .eq("key", "premium_duration_days")
        .maybeSingle();
      const durationDays = parseInt(durationCfg?.value || "30");

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + durationDays);

      await supabase
        .from("profiles")
        .update({
          is_premium: true,
          premium_expires_at: expiresAt.toISOString(),
          paystack_customer_code: data.data.customer?.customer_code || null,
        })
        .eq("id", userId || data.data.metadata?.custom_fields?.[0]?.value);

      // Record revenue
      await supabase.from("revenue_transactions").insert({
        user_id: userId || data.data.metadata?.custom_fields?.[0]?.value,
        type: "premium_subscription",
        amount: paidAmount,
        description: `Premium subscription - ${durationDays} days (Paystack: ${reference})`,
      });

      return new Response(
        JSON.stringify({ success: true, amount: paidAmount, reference }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action. Use ?action=initialize or ?action=verify" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
