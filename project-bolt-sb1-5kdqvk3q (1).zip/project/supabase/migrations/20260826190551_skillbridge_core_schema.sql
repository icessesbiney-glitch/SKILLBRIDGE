/*
# SkillBridge Core Schema

## Overview
Creates the complete database backbone for the SkillBridge learning platform —
a service that helps unemployed adults (22+) build skills, connect with mentors,
find opportunities, and earn premium access.

## New Tables
1. profiles — extends auth.users with platform data (name, age, education, premium flag, admin flag)
2. courses — catalog of learning courses (free + premium)
3. lessons — individual lessons within a course
4. enrollments — tracks user-course enrollment + progress
5. mentors — mentor profiles
6. mentor_requests — learner requests for mentorship
7. opportunities — jobs, internships, gigs, scholarships
8. ad_impressions — tracks ad views for revenue
9. revenue_transactions — all financial transactions (premium + ad revenue)
10. system_config — key-value config (owner allocation %, ad rate, pricing)

## Security (RLS)
- profiles: owner-scoped update; limited public read for names
- courses, lessons, mentors, opportunities: public read
- enrollments, mentor_requests: owner-scoped CRUD
- ad_impressions: insert for anon+authenticated
- revenue_transactions: insert only from client; reads admin-only
- system_config: public read
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  age integer,
  education_level text DEFAULT 'Other',
  phone text DEFAULT '',
  is_premium boolean NOT NULL DEFAULT false,
  premium_expires_at timestamptz,
  is_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_select_all_limited" ON profiles;
CREATE POLICY "profiles_select_all_limited" ON profiles FOR SELECT
  TO authenticated USING (true);

-- ============ COURSES ============
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  level text NOT NULL DEFAULT 'Beginner',
  thumbnail_url text,
  is_premium boolean NOT NULL DEFAULT false,
  instructor_name text NOT NULL DEFAULT 'SkillBridge',
  duration_hours integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "courses_read_all" ON courses;
CREATE POLICY "courses_read_all" ON courses FOR SELECT
  TO anon, authenticated USING (true);

-- ============ LESSONS ============
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  content text,
  video_url text,
  duration_minutes integer DEFAULT 0,
  lesson_order integer NOT NULL DEFAULT 0,
  is_preview boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "lessons_read_all" ON lessons;
CREATE POLICY "lessons_read_all" ON lessons FOR SELECT
  TO anon, authenticated USING (true);

-- ============ ENROLLMENTS ============
CREATE TABLE IF NOT EXISTS enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  progress integer NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, course_id)
);
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "enrollments_select_own" ON enrollments;
CREATE POLICY "enrollments_select_own" ON enrollments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "enrollments_insert_own" ON enrollments;
CREATE POLICY "enrollments_insert_own" ON enrollments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "enrollments_update_own" ON enrollments;
CREATE POLICY "enrollments_update_own" ON enrollments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "enrollments_delete_own" ON enrollments;
CREATE POLICY "enrollments_delete_own" ON enrollments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ MENTORS ============
CREATE TABLE IF NOT EXISTS mentors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  expertise text NOT NULL,
  bio text,
  avatar_url text,
  rating numeric DEFAULT 5.0,
  years_experience integer DEFAULT 0,
  is_available boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE mentors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "mentors_read_all" ON mentors;
CREATE POLICY "mentors_read_all" ON mentors FOR SELECT
  TO anon, authenticated USING (true);

-- ============ MENTOR_REQUESTS ============
CREATE TABLE IF NOT EXISTS mentor_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  mentor_id uuid NOT NULL REFERENCES mentors(id) ON DELETE CASCADE,
  message text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE mentor_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "mentor_requests_select_own" ON mentor_requests;
CREATE POLICY "mentor_requests_select_own" ON mentor_requests FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "mentor_requests_insert_own" ON mentor_requests;
CREATE POLICY "mentor_requests_insert_own" ON mentor_requests FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "mentor_requests_update_own" ON mentor_requests;
CREATE POLICY "mentor_requests_update_own" ON mentor_requests FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "mentor_requests_delete_own" ON mentor_requests;
CREATE POLICY "mentor_requests_delete_own" ON mentor_requests FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ OPPORTUNITIES ============
CREATE TABLE IF NOT EXISTS opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL DEFAULT 'job' CHECK (type IN ('job','internship','gig','scholarship')),
  location text DEFAULT '',
  company text DEFAULT '',
  application_url text,
  is_premium boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE opportunities ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "opportunities_read_all" ON opportunities;
CREATE POLICY "opportunities_read_all" ON opportunities FOR SELECT
  TO anon, authenticated USING (true);

-- ============ AD_IMPRESSIONS ============
CREATE TABLE IF NOT EXISTS ad_impressions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_slot text NOT NULL DEFAULT 'banner',
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE ad_impressions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ad_impressions_insert" ON ad_impressions;
CREATE POLICY "ad_impressions_insert" ON ad_impressions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- ============ REVENUE_TRANSACTIONS ============
CREATE TABLE IF NOT EXISTS revenue_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  type text NOT NULL CHECK (type IN ('premium_subscription','ad_revenue')),
  amount numeric NOT NULL DEFAULT 0,
  description text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE revenue_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "revenue_insert_own" ON revenue_transactions;
CREATE POLICY "revenue_insert_own" ON revenue_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

-- ============ SYSTEM_CONFIG ============
CREATE TABLE IF NOT EXISTS system_config (
  key text PRIMARY KEY,
  value text NOT NULL
);
ALTER TABLE system_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "config_read_all" ON system_config;
CREATE POLICY "config_read_all" ON system_config FOR SELECT
  TO anon, authenticated USING (true);

INSERT INTO system_config (key, value) VALUES
  ('owner_allocation_percent', '10'),
  ('retained_percent', '90'),
  ('ad_revenue_per_impression', '0.02'),
  ('premium_price', '15'),
  ('premium_duration_days', '30')
ON CONFLICT (key) DO NOTHING;

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_lessons_course_id ON lessons(course_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX IF NOT EXISTS idx_mentor_requests_user_id ON mentor_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_ad_impressions_created ON ad_impressions(created_at);
CREATE INDEX IF NOT EXISTS idx_revenue_created ON revenue_transactions(created_at);
