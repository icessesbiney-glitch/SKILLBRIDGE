/*
# SkillBridge Tasks, Wallet & Paystack Schema Extension

## Overview
Extends the SkillBridge platform with three new capabilities:
1. **Tasks** — daily/weekly learning tasks that users complete for rewards
2. **Wallet** — per-user wallet tracking earnings from task rewards and referral bonuses
3. **Paystack payments** — premium subscription payments processed via Paystack

## New Tables
1. `tasks` — catalog of tasks (quiz completion, lesson watch, course finish, etc.)
   - `id` (uuid, PK)
   - `title` (text) — task name shown to users
   - `description` (text) — what the user needs to do
   - `task_type` (text) — category: lesson_complete, quiz_pass, course_complete, daily_login, referral
   - `reward_amount` (numeric) — how much the user earns for completing
   - `target_count` (integer) — how many times the action must be done (default 1)
   - `is_active` (boolean) — whether the task is currently available
   - `expires_at` (timestamptz, nullable) — optional deadline for time-limited tasks
   - `created_at` (timestamptz)

2. `user_tasks` — tracks which users have completed which tasks
   - `id` (uuid, PK)
   - `user_id` (uuid, FK → auth.users, DEFAULT auth.uid())
   - `task_id` (uuid, FK → tasks)
   - `status` (text) — pending, completed, claimed
   - `progress` (integer) — current progress count toward target
   - `completed_at` (timestamptz, nullable)
   - `claimed_at` (timestamptz, nullable) — when the reward was added to wallet
   - `created_at` (timestamptz)
   - UNIQUE(user_id, task_id)

3. `wallet_transactions` — all wallet credits and debits
   - `id` (uuid, PK)
   - `user_id` (uuid, FK → auth.users, DEFAULT auth.uid())
   - `type` (text) — task_reward, referral_bonus, premium_payment, withdrawal
   - `amount` (numeric) — positive for credit, negative for debit
   - `description` (text)
   - `reference` (text, nullable) — Paystack transaction reference for payments
   - `status` (text) — pending, success, failed
   - `created_at` (timestamptz)

## Modified Tables
- `profiles`: adds `wallet_balance` column (numeric, default 0) and `paystack_customer_code` (text, nullable)
- `system_config`: adds new config keys for Paystack and task reward settings

## Security (RLS)
- `tasks`: public read (anon + authenticated) — task catalog is visible to everyone
- `user_tasks`: owner-scoped CRUD — users only see/manage their own task progress
- `wallet_transactions`: owner-scoped SELECT + INSERT; UPDATE restricted to owner
- `profiles` update policy unchanged (already owner-scoped)

## Important Notes
1. The `wallet_balance` column is denormalized for quick display; actual balance is
   the sum of all `wallet_transactions` for the user. Updates to `wallet_balance`
   happen in application code when a transaction is confirmed.
2. Paystack payment verification happens in the `paystack` edge function using
   the service role key — the frontend never touches the secret key.
3. Task reward claiming is a two-step process: mark `user_tasks.claimed_at`,
   then insert a `wallet_transactions` row and update `profiles.wallet_balance`.
*/

-- ============ ADD COLUMNS TO PROFILES ============
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'wallet_balance'
  ) THEN
    ALTER TABLE profiles ADD COLUMN wallet_balance numeric NOT NULL DEFAULT 0;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'paystack_customer_code'
  ) THEN
    ALTER TABLE profiles ADD COLUMN paystack_customer_code text;
  END IF;
END $$;

-- ============ TASKS ============
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  task_type text NOT NULL DEFAULT 'daily_login' CHECK (task_type IN ('lesson_complete','quiz_pass','course_complete','daily_login','referral')),
  reward_amount numeric NOT NULL DEFAULT 0 CHECK (reward_amount >= 0),
  target_count integer NOT NULL DEFAULT 1 CHECK (target_count >= 1),
  is_active boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tasks_read_all" ON tasks;
CREATE POLICY "tasks_read_all" ON tasks FOR SELECT
  TO anon, authenticated USING (true);

-- ============ USER_TASKS ============
CREATE TABLE IF NOT EXISTS user_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','claimed')),
  progress integer NOT NULL DEFAULT 0 CHECK (progress >= 0),
  completed_at timestamptz,
  claimed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, task_id)
);
ALTER TABLE user_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_tasks_select_own" ON user_tasks;
CREATE POLICY "user_tasks_select_own" ON user_tasks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_tasks_insert_own" ON user_tasks;
CREATE POLICY "user_tasks_insert_own" ON user_tasks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_tasks_update_own" ON user_tasks;
CREATE POLICY "user_tasks_update_own" ON user_tasks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "user_tasks_delete_own" ON user_tasks;
CREATE POLICY "user_tasks_delete_own" ON user_tasks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ WALLET_TRANSACTIONS ============
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('task_reward','referral_bonus','premium_payment','withdrawal')),
  amount numeric NOT NULL DEFAULT 0,
  description text DEFAULT '',
  reference text,
  status text NOT NULL DEFAULT 'success' CHECK (status IN ('pending','success','failed')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "wallet_tx_select_own" ON wallet_transactions;
CREATE POLICY "wallet_tx_select_own" ON wallet_transactions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "wallet_tx_insert_own" ON wallet_transactions;
CREATE POLICY "wallet_tx_insert_own" ON wallet_transactions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "wallet_tx_update_own" ON wallet_transactions;
CREATE POLICY "wallet_tx_update_own" ON wallet_transactions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ INSERT TASK SEED DATA ============
INSERT INTO tasks (title, description, task_type, reward_amount, target_count, is_active) VALUES
  ('Complete Your First Lesson', 'Watch any lesson from start to finish to earn your first reward', 'lesson_complete', 2.00, 1, true),
  ('Finish a Course', 'Complete all lessons in any course to earn a bonus', 'course_complete', 10.00, 1, true),
  ('Daily Login Streak', 'Log in 3 days in a row to build your habit and earn rewards', 'daily_login', 1.00, 3, true),
  ('Refer a Friend', 'Invite someone to join SkillBridge — you both earn when they sign up', 'referral', 5.00, 1, true),
  ('Complete 5 Lessons', 'Watch 5 lessons across any courses to boost your learning', 'lesson_complete', 5.00, 5, true)
ON CONFLICT DO NOTHING;

-- ============ ADD NEW SYSTEM CONFIG ============
INSERT INTO system_config (key, value) VALUES
  ('paystack_public_key', ''),
  ('paystack_secret_key', ''),
  ('task_reward_currency', 'GHS'),
  ('min_wallet_withdrawal', '20'),
  ('referral_bonus_amount', '5')
ON CONFLICT (key) DO NOTHING;

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_user_tasks_user_id ON user_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tasks_task_id ON user_tasks(task_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_created ON wallet_transactions(created_at);